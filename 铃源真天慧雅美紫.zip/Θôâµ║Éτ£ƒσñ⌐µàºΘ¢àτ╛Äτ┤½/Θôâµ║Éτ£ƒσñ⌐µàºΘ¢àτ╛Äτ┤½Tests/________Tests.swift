//
//  ________Tests.swift
//  铃源真天慧雅美紫Tests
//
//  Created by 清都山水郎 on 2025/6/18.
//

import Testing
@testable import ________

struct ________Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
