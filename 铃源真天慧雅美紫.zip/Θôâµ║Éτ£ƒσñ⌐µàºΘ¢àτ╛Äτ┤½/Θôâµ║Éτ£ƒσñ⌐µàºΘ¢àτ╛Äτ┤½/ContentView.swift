import SwiftUI

struct ContentView: View {
    @Environment(\.managedObjectContext) private var context
    @EnvironmentObject var chatModel: ChatModel
    @FocusState private var inputIsFocused: Bool
    @State private var showClearConfirm = false

    var body: some View {
        GeometryReader { geometry in
            VStack(spacing: 0) {
                HeaderView(emoji: chatModel.currentEmoji)
                    .overlay(
                        HStack {
                            Spacer()
                            Button(action: {
                                showClearConfirm = true
                            }) {
                                Image(systemName: "trash")
                                    .foregroundColor(.white)
                                    .padding(8)
                                    .background(Color.red)
                                    .clipShape(Circle())
                            }
                            .padding(.trailing)
                            .alert("确定要清空全部聊天记录吗？", isPresented: $showClearConfirm) {
                                Button("取消", role: .cancel) {}
                                Button("清空", role: .destructive) {
                                    chatModel.clearChat()
                                }
                            }
                        }, alignment: .topTrailing
                    )

                ScrollViewReader { scrollProxy in
                    ScrollView {
                        VStack(alignment: .center, spacing: 8) {
                            ForEach(chatModel.messages) { message in
                                VStack(alignment: message.isUser ? .trailing : .leading, spacing: 2) {
                                    HStack {
                                        if message.isUser { Spacer() }
                                        BubbleText(message: message, maxWidth: geometry.size.width * 0.75)
                                        if !message.isUser { Spacer() }
                                    }
                                    .padding(message.isUser ? .trailing : .leading, 16)
                                    .padding(.vertical, 2)
                                    .id(message.id)
                                    
                                    // 为错误消息添加重试按钮
                                    if !message.isUser && message.text.hasPrefix("❌") {
                                        HStack {
                                            Spacer()
                                            Button("重试") {
                                                chatModel.retryLastMessage()
                                            }
                                            .font(.caption)
                                            .foregroundColor(.blue)
                                            .padding(.horizontal, 8)
                                            .padding(.vertical, 4)
                                            .background(Color.blue.opacity(0.1))
                                            .cornerRadius(8)
                                            .disabled(chatModel.isLoading)
                                            Spacer()
                                        }
                                        .padding(.top, 4)
                                    }
                                    
                                    // 时间戳 - 现在显示完整的时间信息
                                    HStack {
                                        if message.isUser { Spacer() }
                                        Text(message.timestampFormatted)
                                            .font(.caption2)
                                            .foregroundColor(.gray)
                                            .padding(.horizontal, 8)
                                        if !message.isUser { Spacer() }
                                    }
                                    .padding(message.isUser ? .trailing : .leading, 24)
                                }
                            }
                            if chatModel.isLoading {
                                LoadingBubble()
                            }
                        }
                        .padding(.vertical)
                        // 使用 iOS 14+ 兼容的 onChange 语法
                        .onChange(of: chatModel.messages.count) { _ in
                            withAnimation(.easeInOut(duration: 0.3)) {
                                if let lastMessage = chatModel.messages.last {
                                    scrollProxy.scrollTo(lastMessage.id, anchor: .bottom)
                                }
                            }
                        }
                    }
                }

                Divider()

                HStack(spacing: 10) {
                    TextField("说点什么...", text: $chatModel.currentInput)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .focused($inputIsFocused)
                        .disabled(chatModel.isLoading)
                        .onSubmit {
                            sendMessage()
                        }

                    Button(action: {
                        sendMessage()
                    }) {
                        Image(systemName: chatModel.isLoading ? "stop.circle.fill" : "paperplane.fill")
                            .padding(10)
                            .foregroundColor(.white)
                            .background(chatModel.isLoading ? Color.orange : Color.pink)
                            .clipShape(Circle())
                    }
                    .disabled(chatModel.currentInput.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty && !chatModel.isLoading)
                }
                .padding()
            }
            .frame(minWidth: 500, minHeight: 600)
            .alert("连接错误", isPresented: $chatModel.showErrorAlert) {
                Button("确定") {
                    chatModel.showErrorAlert = false
                }
                Button("重试") {
                    chatModel.retryLastMessage()
                }
            } message: {
                Text(chatModel.errorMessage ?? "未知错误")
            }
        }
    }

    private func sendMessage() {
        if chatModel.isLoading {
            // 如果正在加载，这里可以实现取消功能
            // 目前只是简单返回
            return
        }
        chatModel.sendMessage()
        inputIsFocused = false
    }
}

struct BubbleText: View {
    let message: ChatMessage
    var maxWidth: CGFloat

    var body: some View {
        Text(message.text)
            .padding(.vertical, 10)
            .padding(.horizontal, 16)
            .background(backgroundColorForMessage)
            .foregroundColor(textColorForMessage)
            .clipShape(BubbleShape(isUser: message.isUser))
            .fixedSize(horizontal: false, vertical: true)
            .frame(maxWidth: maxWidth, alignment: message.isUser ? .trailing : .leading)
    }
    
    private var backgroundColorForMessage: Color {
        if message.isUser {
            return Color(red: 0.99, green: 0.86, blue: 0.91)
        } else if message.text.hasPrefix("❌") {
            return Color.red.opacity(0.1)
        } else {
            return Color(NSColor.windowBackgroundColor)
        }
    }
    
    private var textColorForMessage: Color {
        if message.text.hasPrefix("❌") {
            return Color.red
        } else {
            return Color.primary
        }
    }
}

struct LoadingBubble: View {
    @State private var animationPhase = 0

    var body: some View {
        HStack {
            HStack(spacing: 4) {
                Text("对方正在输入")
                    .italic()
                    .foregroundColor(.gray)
                
                // 动画点点
                HStack(spacing: 2) {
                    ForEach(0..<3, id: \.self) { index in
                        Circle()
                            .fill(Color.gray)
                            .frame(width: 4, height: 4)
                            .opacity(animationPhase == index ? 1.0 : 0.3)
                    }
                }
            }
            .padding(.vertical, 8)
            .padding(.horizontal, 20)
            .background(Color(NSColor.controlBackgroundColor))
            .clipShape(BubbleShape(isUser: false))
            
            Spacer()
        }
        .padding(.leading, 16)
        .onAppear {
            // 开始动画
            Timer.scheduledTimer(withTimeInterval: 0.6, repeats: true) { _ in
                withAnimation(.easeInOut(duration: 0.3)) {
                    animationPhase = (animationPhase + 1) % 3
                }
            }
        }
    }
}

// 🎯 重要更新：这里是时间格式化的关键部分！
extension ChatMessage {
    var timestampFormatted: String {
        let formatter = DateFormatter()
        // 🚀 新的超详细时间格式：年-月-日 时:分:秒
        formatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        return formatter.string(from: timestamp ?? Date())
    }
}
