import SwiftUI

@main
struct 铃源真天慧雅美紫App: App {
    @State private var isLaunchFinished = false
    let persistenceController = PersistenceController.shared

    var body: some Scene {
        WindowGroup {
            if isLaunchFinished {
                ContentView()
                    .environmentObject(ChatModel(context: persistenceController.context))
            } else {
                LaunchView {
                    isLaunchFinished = true
                }
            }
        }
    }
}
