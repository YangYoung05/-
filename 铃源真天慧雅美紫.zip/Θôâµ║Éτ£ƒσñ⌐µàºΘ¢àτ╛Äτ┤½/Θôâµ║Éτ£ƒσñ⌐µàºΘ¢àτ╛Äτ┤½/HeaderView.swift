import SwiftUI

struct HeaderView: View {
    let emoji: String

    var body: some View {
        VStack(spacing: 8) {
            Image("virtual_avatar") // 替换成你的小马头像图片
                .resizable()
                .scaledToFit()
                .frame(width: 120, height: 120)
                .clipShape(Circle())
                .shadow(radius: 8)

            Text(emoji)
                .font(.system(size: 32))
        }
        .frame(maxWidth: .infinity)
        .padding(.top, 20)
    }
}
