import Foundation
import CoreData
import Combine

class ChatModel: ObservableObject {
    @Published var messages: [ChatMessage] = []
    @Published var currentInput: String = ""
    @Published var isLoading: Bool = false
    @Published var currentEmoji: String = "🦄"
    @Published var errorMessage: String? = nil
    @Published var showErrorAlert: Bool = false

    private let context: NSManagedObjectContext
    private var cancellables = Set<AnyCancellable>()

    init(context: NSManagedObjectContext) {
        self.context = context
        loadMessages()
        setupInitialState()
        setupNetworkMonitoring()
    }
    
    private func setupInitialState() {
        // 首次启动自动补欢迎语
        if messages.isEmpty {
            let welcomeText = "你好，我是铃源真天慧雅美紫，也可以叫我小铃，你有什么想和我聊的吗？"
            let welcomeMessage = ChatMessage(id: UUID(), text: welcomeText, isUser: false, emoji: "🦄", timestamp: Date())
            messages.append(welcomeMessage)
            saveToCoreData(welcomeMessage)
            currentEmoji = "🦄"
        } else {
            // 恢复上次AI表情
            if let lastAI = messages.last(where: { !$0.isUser }) {
                currentEmoji = lastAI.emoji
            }
        }
    }
    
    private func setupNetworkMonitoring() {
        // 监听网络状态变化
        LocalModelInterface.shared.$isNetworkAvailable
            .receive(on: DispatchQueue.main)
            .sink { [weak self] isAvailable in
                if !isAvailable && self?.isLoading == true {
                    self?.handleError(.networkUnavailable)
                }
            }
            .store(in: &cancellables)
    }

    func sendMessage() {
        let input = currentInput.trimmingCharacters(in: .whitespacesAndNewlines)
        let singlePunctuations: Set<String> = ["。", "，", ",", ".", "!", "！", "?", "？", "、", ";", "；", "-", "——"]
        
        // 用户输入：去除句首所有标点和空白
        let cleanInput = input.replacingOccurrences(of: #"^[。，,\.!！?？、;；\-——\s]*"#, with: "", options: .regularExpression)

        // 过滤无效用户输入（空或只有标点不发送）
        guard !cleanInput.isEmpty, !isLoading, !singlePunctuations.contains(cleanInput) else { return }

        let userMessage = ChatMessage(id: UUID(), text: cleanInput, isUser: true, emoji: "🙂", timestamp: Date())
        messages.append(userMessage)
        saveToCoreData(userMessage)

        currentInput = ""
        isLoading = true
        clearError() // 清除之前的错误

        // 传递 ChatMessage 数组
        LocalModelInterface.shared.sendMessage(messages: messages) { [weak self] result in
            DispatchQueue.main.async {
                self?.isLoading = false
                
                switch result {
                case .success(let response):
                    self?.handleSuccessResponse(response)
                case .failure(let error):
                    self?.handleError(error)
                }
            }
        }
    }
    
    private func handleSuccessResponse(_ response: String) {
        let aiTextRaw = response.trimmingCharacters(in: .whitespacesAndNewlines)
        let singlePunctuations: Set<String> = ["。", "，", ",", ".", "!", "！", "?", "？", "、", ";", "；", "-", "——"]
        
        // 1. 去除句首所有标点和空白
        var aiText = aiTextRaw.replacingOccurrences(of: #"^[。，,\.!！?？、;；\-——\s]*"#, with: "", options: .regularExpression)
        
        // 2. 去掉常见AI开头"称呼"前缀
        let prefixPatterns = [
            #"^小铃[!！:：,，\s]+"#,
            #"^你好[，,]小铃[!！:：,，\s]*"#,
            #"^嗨[，,]小铃[!！:：,，\s]*"#,
            #"^铃源真天慧雅美紫[!！:：,，\s]*"#
        ]
        for pattern in prefixPatterns {
            aiText = aiText.replacingOccurrences(of: pattern, with: "", options: .regularExpression)
        }
        
        // 3. 再次清理开头
        aiText = aiText.trimmingCharacters(in: .whitespacesAndNewlines)
        
        // 4. 过滤：空、只有标点的不显示
        if !aiText.isEmpty && !singlePunctuations.contains(aiText) {
            let aiEmoji = EmojiManager.emoji(for: aiText)
            let aiMessage = ChatMessage(id: UUID(), text: aiText, isUser: false, emoji: aiEmoji, timestamp: Date())
            messages.append(aiMessage)
            saveToCoreData(aiMessage)
            currentEmoji = aiEmoji
        } else {
            // 如果处理后的文本为空，显示默认回复
            let defaultText = "我在呢～"
            let aiEmoji = EmojiManager.emoji(for: defaultText)
            let aiMessage = ChatMessage(id: UUID(), text: defaultText, isUser: false, emoji: aiEmoji, timestamp: Date())
            messages.append(aiMessage)
            saveToCoreData(aiMessage)
            currentEmoji = aiEmoji
        }
    }
    
    private func handleError(_ error: ChatError) {
        // 根据不同错误类型提供不同的用户友好提示
        let errorText: String
        let shouldShowAlert: Bool
        
        switch error {
        case .networkUnavailable:
            errorText = "网络连接出现问题，请检查网络设置"
            shouldShowAlert = true
        case .serverNotRunning:
            errorText = "本地AI服务未启动，请先启动 Ollama 服务"
            shouldShowAlert = true
        case .modelNotFound:
            errorText = "AI模型未找到，请确认已安装 qwen2:7b 模型"
            shouldShowAlert = true
        case .timeout:
            errorText = "响应超时，请稍后重试"
            shouldShowAlert = false
        case .invalidResponse, .unknown:
            errorText = "AI暂时无法回应，请稍后重试"
            shouldShowAlert = false
        }
        
        // 添加错误消息到聊天记录
        let errorMessage = ChatMessage(
            id: UUID(),
            text: "❌ \(errorText)",
            isUser: false,
            emoji: "😅",
            timestamp: Date()
        )
        messages.append(errorMessage)
        saveToCoreData(errorMessage)
        currentEmoji = "😅"
        
        // 根据错误严重程度决定是否显示警告弹窗
        if shouldShowAlert {
            self.errorMessage = error.localizedDescription
            self.showErrorAlert = true
        }
    }
    
    private func clearError() {
        errorMessage = nil
        showErrorAlert = false
    }

    func clearChat() {
        messages.removeAll()
        clearError()
        
        // Core Data 批量删除
        let fetchRequest: NSFetchRequest<NSFetchRequestResult> = NSFetchRequest(entityName: "ChatEntity")
        let batchDeleteRequest = NSBatchDeleteRequest(fetchRequest: fetchRequest)
        do {
            try context.execute(batchDeleteRequest)
            try context.save()
        } catch {
            print("清空聊天记录失败：\(error)")
        }
        
        // 补充欢迎语
        let welcomeText = "你好，我是铃源真天慧雅美紫，也可以叫我小铃，你有什么想和我聊的吗？"
        let welcomeMessage = ChatMessage(id: UUID(), text: welcomeText, isUser: false, emoji: "🦄", timestamp: Date())
        messages.append(welcomeMessage)
        saveToCoreData(welcomeMessage)
        currentEmoji = "🦄"
    }

    func loadMessages() {
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "ChatEntity")
        fetchRequest.sortDescriptors = [NSSortDescriptor(key: "timestamp", ascending: true)]
        do {
            let results = try context.fetch(fetchRequest)
            messages = results.compactMap { obj in
                guard
                    let id = obj.value(forKey: "id") as? UUID,
                    let text = obj.value(forKey: "text") as? String,
                    let isUser = obj.value(forKey: "isUser") as? Bool,
                    let emoji = obj.value(forKey: "emoji") as? String,
                    let timestamp = obj.value(forKey: "timestamp") as? Date
                else { return nil }
                return ChatMessage(id: id, text: text, isUser: isUser, emoji: emoji, timestamp: timestamp)
            }
        } catch {
            print("加载历史记录失败：\(error)")
            // 如果加载失败，创建空的消息数组
            messages = []
        }
    }

    func saveToCoreData(_ message: ChatMessage) {
        let entity = NSEntityDescription.insertNewObject(forEntityName: "ChatEntity", into: context)
        entity.setValue(message.id, forKey: "id")
        entity.setValue(message.text, forKey: "text")
        entity.setValue(message.isUser, forKey: "isUser")
        entity.setValue(message.emoji, forKey: "emoji")
        entity.setValue(message.timestamp, forKey: "timestamp")
        do {
            try context.save()
        } catch {
            print("保存消息失败：\(error)")
            // 如果保存失败，至少消息在内存中还存在
        }
    }
    
    func retryLastMessage() {
        // 重试功能：重新发送最后一条用户消息
        guard let lastUserMessage = messages.last(where: { $0.isUser }), !isLoading else { return }
        
        // 移除最后的错误消息（如果存在）
        if let lastMessage = messages.last, !lastMessage.isUser && lastMessage.text.hasPrefix("❌") {
            messages.removeLast()
            // 同时从数据库删除
            let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "ChatEntity")
            fetchRequest.predicate = NSPredicate(format: "id == %@", lastMessage.id as CVarArg)
            do {
                let results = try context.fetch(fetchRequest)
                for object in results {
                    context.delete(object)
                }
                try context.save()
            } catch {
                print("删除错误消息失败：\(error)")
            }
        }
        
        currentInput = lastUserMessage.text
        sendMessage()
    }
    
    deinit {
        cancellables.removeAll()
    }
}

// 聊天消息结构体
struct ChatMessage: Identifiable, Equatable {
    let id: UUID
    let text: String
    let isUser: Bool
    let emoji: String
    let timestamp: Date?
    
    static func == (lhs: ChatMessage, rhs: ChatMessage) -> Bool {
        return lhs.id == rhs.id
    }
}
