import SwiftUI

struct LaunchView: View {
    var onFinish: () -> Void
    @State private var isLoading = true

    var body: some View {
        ZStack {
            Color(.systemPink).opacity(0.2).edgesIgnoringSafeArea(.all)
            VStack(spacing: 32) {
                Image("virtual_avatar")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 180, height: 180)
                    .shadow(radius: 16)
                Text("你好呀，我叫铃源真天慧雅美紫，很高兴见到你！")
                    .font(.title2)
                    .foregroundColor(.pink)
                ProgressView()
                    .progressViewStyle(CircularProgressViewStyle())
            }
        }
        .onAppear {
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.2) {
                onFinish()
            }
        }
    }
}
