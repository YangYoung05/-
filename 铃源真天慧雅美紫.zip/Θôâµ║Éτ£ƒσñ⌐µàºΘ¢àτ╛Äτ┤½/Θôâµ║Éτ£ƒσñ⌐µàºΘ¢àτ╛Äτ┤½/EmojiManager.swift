import Foundation

struct EmojiManager {
    static func emoji(for text: String) -> String {
        let lower = text.lowercased()
        if lower.contains("笑") || lower.contains("开心") || lower.contains("happy") { return "😄" }
        if lower.contains("哭") || lower.contains("sad") || lower.contains("难过") { return "😢" }
        if lower.contains("爱") || lower.contains("喜欢") || lower.contains("love") { return "😍" }
        if lower.contains("生气") || lower.contains("angry") { return "😡" }
        if lower.contains("棒") || lower.contains("赞") || lower.contains("great") { return "👍" }
        if lower.contains("困") || lower.contains("累") || lower.contains("tired") { return "🥱" }
        if lower.contains("你好吗") || lower.contains("hello") || lower.contains("hi") { return "👋" }
        if lower.contains("?") || lower.contains("？") { return "🤔" }
        return "😊"
    }
}
