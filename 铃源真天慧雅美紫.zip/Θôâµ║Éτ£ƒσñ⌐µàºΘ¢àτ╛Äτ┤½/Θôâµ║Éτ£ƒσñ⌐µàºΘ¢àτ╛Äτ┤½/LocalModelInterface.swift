import Foundation
import Network
import Combine // 添加 Combine 导入

enum ChatError: Error, LocalizedError {
    case networkUnavailable
    case serverNotRunning
    case invalidResponse
    case modelNotFound
    case timeout
    case unknown(String)
    
    var errorDescription: String? {
        switch self {
        case .networkUnavailable:
            return "网络连接不可用"
        case .serverNotRunning:
            return "本地模型服务未运行，请检查 Ollama 是否启动"
        case .invalidResponse:
            return "模型响应格式错误"
        case .modelNotFound:
            return "模型未找到，请检查 qwen2:7b 是否已安装"
        case .timeout:
            return "请求超时，请稍后重试"
        case .unknown(let message):
            return "未知错误：\(message)"
        }
    }
}

struct OllamaChatRequest: Codable {
    let model: String
    let messages: [OllamaMessage]
    let stream: Bool = false
}

struct OllamaMessage: Codable {
    let role: String
    let content: String
}

struct OllamaChatResponse: Codable {
    let message: OllamaMessage
    let done: Bool?
}

struct OllamaErrorResponse: Codable {
    let error: String
}

class LocalModelInterface: ObservableObject { // 添加 ObservableObject 协议
    static let shared = LocalModelInterface()
    private let monitor = NWPathMonitor()
    private let queue = DispatchQueue(label: "NetworkMonitor")
    @Published private(set) var isNetworkAvailable = true // 现在 @Published 可以正常工作了
    
    private init() {
        setupNetworkMonitoring()
    }
    
    private func setupNetworkMonitoring() {
        monitor.pathUpdateHandler = { [weak self] path in
            DispatchQueue.main.async {
                self?.isNetworkAvailable = path.status == .satisfied
            }
        }
        monitor.start(queue: queue)
    }
    
    func sendMessage(messages: [ChatMessage], completion: @escaping (Result<String, ChatError>) -> Void) {
        // 检查网络连接
        guard isNetworkAvailable else {
            completion(.failure(.networkUnavailable))
            return
        }
        
        // 确保至少有一条消息
        guard !messages.isEmpty else {
            completion(.failure(.invalidResponse))
            return
        }
        
        // 转换消息格式 - 基于 ChatMessage 的 isUser 属性
        let ollamaMessages = messages.map { message in
            OllamaMessage(
                role: message.isUser ? "user" : "assistant",
                content: message.text
            )
        }
        
        let url = URL(string: "http://127.0.0.1:11434/api/chat")!
        let request = OllamaChatRequest(model: "qwen2:7b", messages: ollamaMessages)
        
        var urlRequest = URLRequest(url: url)
        urlRequest.httpMethod = "POST"
        urlRequest.setValue("application/json", forHTTPHeaderField: "Content-Type")
        urlRequest.timeoutInterval = 30.0 // 设置超时时间
        
        do {
            urlRequest.httpBody = try JSONEncoder().encode(request)
        } catch {
            completion(.failure(.unknown("请求编码失败: \(error.localizedDescription)")))
            return
        }
        
        let task = URLSession.shared.dataTask(with: urlRequest) { [weak self] data, response, error in
            // 处理网络错误
            if let error = error {
                let chatError: ChatError
                let nsError = error as NSError
                
                switch nsError.code {
                case NSURLErrorTimedOut:
                    chatError = .timeout
                case NSURLErrorCannotConnectToHost, NSURLErrorCannotFindHost:
                    chatError = .serverNotRunning
                case NSURLErrorNotConnectedToInternet:
                    chatError = .networkUnavailable
                default:
                    chatError = .unknown(error.localizedDescription)
                }
                completion(.failure(chatError))
                return
            }
            
            // 检查 HTTP 状态码
            if let httpResponse = response as? HTTPURLResponse {
                switch httpResponse.statusCode {
                case 200:
                    break // 正常响应
                case 404:
                    completion(.failure(.modelNotFound))
                    return
                case 500...599:
                    completion(.failure(.serverNotRunning))
                    return
                default:
                    completion(.failure(.unknown("HTTP 错误: \(httpResponse.statusCode)")))
                    return
                }
            }
            
            guard let data = data else {
                completion(.failure(.invalidResponse))
                return
            }
            
            // 尝试解析错误响应
            if let errorResponse = try? JSONDecoder().decode(OllamaErrorResponse.self, from: data) {
                if errorResponse.error.contains("model") && errorResponse.error.contains("not found") {
                    completion(.failure(.modelNotFound))
                } else {
                    completion(.failure(.unknown(errorResponse.error)))
                }
                return
            }
            
            // 解析正常响应
            self?.parseResponse(data: data, completion: completion)
        }
        
        task.resume()
    }
    
    private func parseResponse(data: Data, completion: @escaping (Result<String, ChatError>) -> Void) {
        let dataString = String(data: data, encoding: .utf8) ?? ""
        
        // 如果是流式响应，按行解析
        if dataString.contains("\n") {
            var fullContent = ""
            let lines = dataString.components(separatedBy: .newlines)
            
            for line in lines {
                let trimmedLine = line.trimmingCharacters(in: .whitespacesAndNewlines)
                if trimmedLine.isEmpty { continue }
                
                if let lineData = trimmedLine.data(using: .utf8),
                   let response = try? JSONDecoder().decode(OllamaChatResponse.self, from: lineData) {
                    fullContent += response.message.content
                    
                    // 如果收到 done 标志，提前结束
                    if response.done == true {
                        break
                    }
                }
            }
            
            if fullContent.isEmpty {
                completion(.failure(.invalidResponse))
            } else {
                completion(.success(fullContent))
            }
        } else {
            // 单次响应解析
            do {
                let response = try JSONDecoder().decode(OllamaChatResponse.self, from: data)
                if response.message.content.isEmpty {
                    completion(.failure(.invalidResponse))
                } else {
                    completion(.success(response.message.content))
                }
            } catch {
                // 如果JSON解码失败，尝试直接返回原始字符串
                if !dataString.isEmpty {
                    completion(.success(dataString))
                } else {
                    completion(.failure(.invalidResponse))
                }
            }
        }
    }
    
    deinit {
        monitor.cancel()
    }
}
