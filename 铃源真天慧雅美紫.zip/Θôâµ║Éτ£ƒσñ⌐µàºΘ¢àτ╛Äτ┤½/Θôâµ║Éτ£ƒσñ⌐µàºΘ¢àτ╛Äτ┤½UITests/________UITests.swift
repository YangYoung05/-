import Foundation

// 只需要这一份
struct OllamaChatRequest: Codable {
    let model: String
    let messages: [OllamaMessage]
}

struct OllamaMessage: Codable {
    let role: String // "user" or "assistant"
    let content: String
}

struct OllamaChatResponse: Codable {
    let message: OllamaMessage
}

class LocalModelInterface {
    static let shared = LocalModelInterface()
    private init() {}

    /// 向 Ollama 发送消息，messages 是历史消息（轮流 user/assistant），最新一条是你要发的内容
    func sendMessage(messages: [String], completion: @escaping (String?) -> Void) {
        // Ollama 服务器地址
        guard let url = URL(string: "http://127.0.0.1:11434/api/chat") else {
            completion("❌ 无法构造 Ollama 地址")
            return
        }

        // 构造角色历史
        let msgs = messages.enumerated().map { idx, msg in
            OllamaMessage(role: idx % 2 == 0 ? "user" : "assistant", content: msg)
        }

        let req = OllamaChatRequest(model: "qwen2:7b", messages: msgs)

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try? JSONEncoder().encode(req)

        // 打印调试请求内容
        if let body = request.httpBody, let bodyStr = String(data: body, encoding: .utf8) {
            print("📤 请求发送到 Ollama:\n\(bodyStr)")
        }

        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("❌ 网络/模型请求出错: \(error.localizedDescription)")
                completion("❌ 网络/模型错误")
                return
            }
            // Ollama 返回的是流式响应, 这里简单解析第一个完整 json 块
            guard let data = data, let text = String(data: data, encoding: .utf8),
                  let jsonLine = text.split(separator: "\n").first,
                  let jsonData = jsonLine.data(using: .utf8),
                  let result = try? JSONDecoder().decode(OllamaChatResponse.self, from: jsonData) else {
                completion("⚠️ 响应解析失败")
                return
            }
            completion(result.message.content)
        }
        task.resume()
    }
}
