//
//  WenYanTests.swift
//  WenYanTests
//
//  Created by 清都山水郎 on 2025/9/9.
//

import Testing
@testable import WenYan

struct WenYanTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
