# 问言

问言 是一款面向中文成语学习与内容创作的 macOS 桌面应用。它结合阿里云 DashScope 模型，提供“释言 / 视言”结构化解读、CosyVoice 配音，以及 16:9 格式的三段短视频脚本与生成流水线。最新版本优化了长队列场景，支持任务持久化、断网自动恢复与模型兜底，帮助运营、教育及内容创作者在弱网络环境下也能稳定产出国风多媒体素材。

## 功能总览
- **成语速查 + 智能解读**：输入任意成语或快速选择常用成语，一次性生成“释言（分 / 合）”与“视言（三脚本）”三种内容，保持文本同步呈现。
- **脚本级视频创作**：三段脚本按原有“三栏卡片”排布，一次性排入队列并顺序处理，16:9 视频框实时展示进度、剩余时间与提示信息。
- **任务持久化与断网恢复**：视频 `task_id` 与本地音频/脚本序列化保存，断网或应用退出后可自动恢复轮询、补回成片。
- **AI 配音**：优先使用 DashScope CosyVoice v2 WebSocket API，同步落盘 MP3；如云端失败可回退 HTTP 或 macOS 系统 TTS。
- **异常友好体验**：文本生成支持模型降级与指数退避，视频轮询内建网络监控、断网续跑及状态提示，显著降低超时失败率。

## 目录结构
```
WenYan/
├── ContentView.swift       # 主界面与交互逻辑
├── WenYanApp.swift         # App 入口（macOS SwiftUI）
├── Config.swift            # DashScope 配置、模型、网络选项
├── IdiomExplainer.swift    # 成语解读与脚本生成请求封装
├── AliTTSClient.swift      # CosyVoice TTS 客户端（WS + HTTP + 系统回退）
├── VideoComposer.swift     # 文生视频任务下发、轮询、进度估计、音视频混流、网络恢复
├── Models.swift            # IdiomContent 数据模型
├── TextUtils.swift         # 公共工具方法（如 CJK 字符判定）
└── Assets.xcassets         # 资源（App Icon 等）
```

## 环境依赖
- macOS 15.5+，Xcode 15 或更新版本
- Swift 5.9
- 阿里云 DashScope 账号及有效 API Key（文本生成 + CosyVoice + wanx2.1-t2v-plus 视频服务权限）

## 安装与运行
1. 克隆仓库并打开工程：
   ```bash
   git clone <your-repo>
   cd <your-repo>
   open WenYan.xcodeproj
   ```
2. 配置 DashScope API Key：
   - **开发期推荐**：在运行 Scheme 的 `Arguments > Environment` 中新增 `DASHSCOPE_API_KEY`。
   - **或** 在 `Config.swift` 中替换默认的占位密钥（不建议提交真实密钥）。
3. 根据网络环境选择是否禁用系统代理（`Config.disableSystemProxy`）。某些公司代理或 VPN 下关闭代理可显著降低 Socket 错误。
4. 选择 `My Mac` 目标并运行。首次构建会请求麦克风 / 音频输出权限。

## 使用指南
1. **输入或选择成语**：在顶部输入框键入成语，或点击常用成语按钮；点击“生成 释言 / 视言”，三段文本会同时生成并展示。
2. **阅读生成内容**：应用展示“释言（分）”“释言（合）”与三条脚本；文本生成失败时会提示当前重试状态或降级模型。
3. **音频合成**：点击“试听释言配音”调用 CosyVoice；TTS 流程会自动落盘音频，并在断网时提示“待网络恢复”。
4. **三段视频生成**：点击“生成三段视频并嵌入配音”后，原有横向三栏卡片会依次更新状态。应用背后按队列顺序执行任务，生成好的 MP4 文件保存在文档目录。
5. **中断后恢复**：若应用退出或网络断开，重新打开时会自动读取队列并继续未完成的任务；也可手动查看提示信息决定是否重试。

## 配置说明
- `Config.textModel`：默认使用 `qwen-max-latest`。如需节省成本可改为 `qwen-plus`。
- `Config.videoModel`：默认为 `wan2.2-t2v-plus`；若账号暂未开通可更换为其他 DashScope 文生视频模型。
- `Config.ttsPreferWebSocket`：设置为 `false` 可直接使用 HTTP TTS。
- `Config.textFallbackModel`：文本生成主模型连续失败时降级到 `qwen-plus`，提升稳定性。
- `VideoComposer` 强制 wan2.2 输出 `size=832*480`（16:9 480P），并在其他模型下保留兜底逻辑，保证三栏 16:9 视频框显示正常。
- 视频队列、配音文件、`task_id` 会持久化在用户文档目录，重启即可继续。

## 常见问题
| 问题 | 处理建议 |
| --- | --- |
| **文本生成频繁超时 (-1001)** | 程序会自动降级模型并指数退避重试；若仍失败，建议避开高峰时段或检查本地网络。 |
| **视频始终排队 / 超时** | 队列会自动持久化；请保持网络畅通，或在 DashScope 控制台申请更高并发配额。队列中的任务可在 UI 里查看提示并等待恢复。 |
| **断网后任务丢失** | 任务会持久化在文档目录，重新联网后应用会自动恢复轮询；必要时可点击“生成三段视频”重新触发。 |
| **TTS 失败** | 确认 CosyVoice 权限、文本长度 ≤ 2000 billing 字符，并核对 `Config.ttsVoice` 是否存在。失败时会落回系统 TTS。 |
| **代理导致的 Socket 错误** | 将 `Config.disableSystemProxy` 设为 `true`，或在系统层排除相关域名。 |

## 调试技巧
- 控制台会输出 `T2V(Composer) 下单尝试变体 #n`、`☁️ 使用云端API合成语音` 等日志，可用来验证请求是否触达服务端。
- `_tripletState.jobs` 持久化在 `Documents/video_jobs.json`，调试时可打开该文件确认队列内容。
- 若需命令行测试接口，可参考 DashScope 文档使用 `curl`/`httpie` 进行验证，并对照应用中的请求体。

## 计划扩展
- 支持自定义视频脚本模版与演绎风格
- 增加可视化“待恢复任务”管理面板
- 集成更多国学知识图谱，拓展成语语境推荐

## 许可说明
当前仓库未指定开源协议，默认保留所有权利。若需对外发布或授权，请补充适当的 LICENSE 文件。
