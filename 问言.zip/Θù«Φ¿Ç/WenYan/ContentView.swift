import SwiftUI
import AVKit
import Combine

fileprivate enum WenYanTheme {
    // 更浅、更暖的主背景：柔和暖玉绿到浅金翠，整体通透高端
    static let background = LinearGradient(
        colors: [
            Color(red: 34 / 255, green: 72 / 255, blue: 62 / 255),      // 暗玉青，保持深度
            Color(red: 60 / 255, green: 108 / 255, blue: 82 / 255),     // 过渡暖翡绿
            Color(red: 110 / 255, green: 158 / 255, blue: 112 / 255)    // 浅暖玉翠
        ],
        startPoint: .topLeading,
        endPoint: .bottomTrailing
    )
    // 顶部横幅：苍翠 → 柔和暖翡翠 → 柠檬玉光，突出暖调层次
    static let bannerGradient = LinearGradient(
        colors: [
            Color(red: 74 / 255, green: 130 / 255, blue: 108 / 255),    // 苍翠基色
            Color(red: 126 / 255, green: 182 / 255, blue: 142 / 255),   // 暖翡翠核心
            Color(red: 230 / 255, green: 238 / 255, blue: 182 / 255)    // 浅柠檬玉光
        ],
        startPoint: .topLeading,
        endPoint: .bottomTrailing
    )
    // 主操作渐变：云感暖翡翠，保持绿色主基调并显轻盈
    static let primaryGradient = LinearGradient(
        colors: [
            Color(red: 108 / 255, green: 214 / 255, blue: 168 / 255),   // 温润翡翠
            Color(red: 156 / 255, green: 232 / 255, blue: 186 / 255),   // 轻柔玉绿
            Color(red: 210 / 255, green: 248 / 255, blue: 206 / 255)    // 雾感嫩绿
        ],
        startPoint: .topLeading,
        endPoint: .bottomTrailing
    )
    // 次级强调：暖绿过渡至香槟金，提升尊贵感
    static let secondaryGradient = LinearGradient(
        colors: [
            Color(red: 172 / 255, green: 214 / 255, blue: 138 / 255),   // 暖嫩青绿
            Color(red: 233 / 255, green: 216 / 255, blue: 150 / 255)    // 香槟玉金
        ],
        startPoint: .topLeading,
        endPoint: .bottomTrailing
    )
    // 三级强调：薄荷奶白 → 暖翡翠薄光，适合柔和按钮
    static let tertiaryGradient = LinearGradient(
        colors: [
            Color(red: 160 / 255, green: 226 / 255, blue: 196 / 255),   // 薄荷奶白
            Color(red: 208 / 255, green: 244 / 255, blue: 210 / 255)    // 暖翡翠薄光
        ],
        startPoint: .topLeading,
        endPoint: .bottomTrailing
    )
    static let disabledGradient = LinearGradient(
        colors: [
            Color.white.opacity(0.20),
            Color.white.opacity(0.09)
        ],
        startPoint: .topLeading,
        endPoint: .bottomTrailing
    )
    // 主色 & 次级强调色（更柔和、更浅、更暖）
    static let accent = Color(red: 152 / 255, green: 236 / 255, blue: 188 / 255)          // 主翡翠色（提亮）
    static let accentSecondary = Color(red: 220 / 255, green: 204 / 255, blue: 146 / 255) // 暖金青
    static let textPrimary = Color.white.opacity(0.96)
    static let textSecondary = Color.white.opacity(0.78)
    static let mutedText = Color.white.opacity(0.66)
    static let chipGradient = LinearGradient(
        colors: [Color.white.opacity(0.26), Color.white.opacity(0.10)],
        startPoint: .topLeading,
        endPoint: .bottomTrailing
    )
    static let chipStroke = Color.white.opacity(0.28)
    static let cardStroke = Color.white.opacity(0.26)
    static let cardShadow = Color.black.opacity(0.28)
    static let cardGlow = Color.white.opacity(0.08)
    static let innerBackground = Color.white.opacity(0.16)
    static let innerStroke = Color.white.opacity(0.20)
    static let textFieldBackground = Color.white.opacity(0.18)
    static let progressTint = Color(red: 196 / 255, green: 214 / 255, blue: 160 / 255)    // 更轻盈的进度色
}

private struct GlassCard<Content: View>: View {
    private let content: Content

    init(@ViewBuilder content: () -> Content) {
        self.content = content()
    }

    var body: some View {
        content
            .padding(22)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(
                RoundedRectangle(cornerRadius: 30, style: .continuous)
                    .fill(.ultraThinMaterial)
                    .background(
                        RoundedRectangle(cornerRadius: 30, style: .continuous)
                            .fill(WenYanTheme.cardGlow)
                            .blur(radius: 35)
                    )
            )
            .overlay(
                RoundedRectangle(cornerRadius: 30, style: .continuous)
                    .stroke(WenYanTheme.cardStroke, lineWidth: 1)
            )
            .shadow(color: WenYanTheme.cardShadow.opacity(0.25), radius: 25, x: 0, y: 18)
    }
}

private struct GradientButtonStyle: ButtonStyle {
    @Environment(\.isEnabled) private var isEnabled

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.headline.weight(.semibold))
            .foregroundStyle(WenYanTheme.textPrimary)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 16)
            .background(
                RoundedRectangle(cornerRadius: 22, style: .continuous)
                    .fill(isEnabled ? WenYanTheme.primaryGradient : WenYanTheme.disabledGradient)
            )
            .overlay(
                RoundedRectangle(cornerRadius: 22, style: .continuous)
                    .stroke(Color.white.opacity(0.25), lineWidth: 1)
            )
            .shadow(color: isEnabled ? WenYanTheme.cardShadow.opacity(0.45) : .clear, radius: 20, x: 0, y: 14)
            .opacity(configuration.isPressed ? 0.92 : 1)
            .scaleEffect(configuration.isPressed ? 0.99 : 1)
            .animation(.easeOut(duration: 0.18), value: configuration.isPressed)
    }
}

struct ContentView: View {
    @State private var inputText = ""
    @State private var selectedIdiom = ""
    @StateObject private var idiomExplainer = IdiomExplainer()
    @StateObject private var ttsClient = AliTTSClient()
    @StateObject private var videoComposer = VideoComposer()
    
    private let commonIdioms = [
        "画龙点睛", "守株待兔", "杯弓蛇影", "刻舟求剑",
        "叶公好龙", "买椟还珠", "班门弄斧", "破釜沉舟", "卧薪尝胆"
    ]
    
    var body: some View {
        ZStack {
            WenYanTheme.background
                .ignoresSafeArea()
            
            ScrollView(showsIndicators: false) {
                VStack(spacing: 28) {
                    header
                    
                    GlassCard {
                        idiomInputSection
                    }
                    
                    if let content = idiomExplainer.content {
                        GlassCard {
                            idiomDetailSection(content: content)
                        }
                        
                        GlassCard {
                            idiomMediaSection(content: content)
                        }
                    }
                }
                .padding(.horizontal, 22)
                .padding(.vertical, 32)
            }
        }
        .tint(WenYanTheme.accentSecondary)
        .onAppear {
            videoComposer.restorePendingTaskIfNeeded()
            Task {
                let pending = await MainActor.run { _tripletState.jobs.filter { $0.status != .succeeded && $0.status != .failed } }
                for job in pending {
                    await runJob(job.id)
                }
            }
        }
    }
    
    private var header: some View {
        ZStack(alignment: .leading) {
            RoundedRectangle(cornerRadius: 36, style: .continuous)
                .fill(WenYanTheme.bannerGradient)
                .overlay(
                    LinearGradient(
                        colors: [Color.white.opacity(0.25), Color.clear],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                    .blur(radius: 24)
                )
                .overlay(
                    RoundedRectangle(cornerRadius: 36, style: .continuous)
                        .stroke(WenYanTheme.innerStroke.opacity(0.4), lineWidth: 1)
                )
            
            VStack(alignment: .leading, spacing: 12) {
                Text(selectedIdiom.isEmpty ? "问言 · 成语智解" : selectedIdiom)
                    .font(.system(size: 32, weight: .heavy, design: .serif))
                    .foregroundStyle(WenYanTheme.textPrimary)
                Text("AI 释义 · 视听创作")
                    .font(.subheadline.weight(.medium))
                    .foregroundStyle(WenYanTheme.textSecondary)
                HStack(spacing: 12) {
                    Label("输入成语，唤醒释言", systemImage: "sparkles")
                        .font(.footnote)
                        .foregroundStyle(WenYanTheme.textSecondary)
                    Spacer()
                    Text(Date().formatted(date: .abbreviated, time: .omitted))
                        .font(.caption.monospaced())
                        .foregroundStyle(WenYanTheme.mutedText)
                }
            }
            .padding(30)
        }
        .frame(maxWidth: .infinity)
    }
    
    private var idiomInputSection: some View {
        VStack(alignment: .leading, spacing: 22) {
            VStack(alignment: .leading, spacing: 6) {
                Text("成语输入")
                    .font(.title3.weight(.semibold))
                    .foregroundStyle(WenYanTheme.textPrimary)
                Text("输入或选择成语，AI 即刻奉上释义与多媒体脚本")
                    .font(.footnote)
                    .foregroundStyle(WenYanTheme.textSecondary)
            }
            
            TextField("例如: 画龙点睛", text: $inputText)
                .padding(.vertical, 14)
                .padding(.horizontal, 16)
                .background(
                    RoundedRectangle(cornerRadius: 18, style: .continuous)
                        .fill(WenYanTheme.textFieldBackground)
                )
                .overlay(
                    RoundedRectangle(cornerRadius: 18, style: .continuous)
                        .stroke(WenYanTheme.innerStroke, lineWidth: 1)
                )
                .foregroundStyle(WenYanTheme.textPrimary)
                .tint(WenYanTheme.accentSecondary)
            
            VStack(alignment: .leading, spacing: 12) {
                Text("或选择常用成语")
                    .font(.subheadline.weight(.medium))
                    .foregroundStyle(WenYanTheme.textSecondary)
                LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 12), count: 3), spacing: 12) {
                    ForEach(commonIdioms, id: \.self) { idiom in
                        Button {
                            inputText = idiom
                            selectedIdiom = idiom
                            Task {
                                do {
                                    _ = try await idiomExplainer.fetchContentAndScripts(for: idiom)
                                } catch {
                                    // 错误处理在 IdiomExplainer 内部完成
                                }
                            }
                        } label: {
                            Text(idiom)
                                .font(.caption.weight(.semibold))
                                .padding(.vertical, 8)
                                .padding(.horizontal, 12)
                                .frame(maxWidth: .infinity)
                                .foregroundStyle(WenYanTheme.textPrimary)
                                .background(
                                    Capsule(style: .continuous)
                                        .fill(WenYanTheme.chipGradient)
                                )
                                .overlay(
                                    Capsule(style: .continuous)
                                        .stroke(WenYanTheme.chipStroke, lineWidth: 1)
                                )
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
            
            Button(action: generateContent) {
                HStack(spacing: 10) {
                    if idiomExplainer.isLoading {
                        ProgressView()
                            .progressViewStyle(.circular)
                    }
                    Image(systemName: "wand.and.stars.inverse")
                    Text(idiomExplainer.isLoading ? "生成中…" : "生成 释言 / 视言")
                }
            }
            .buttonStyle(GradientButtonStyle())
            .disabled(inputText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || idiomExplainer.isLoading)

            if !idiomExplainer.errorMessage.isEmpty {
                Label(idiomExplainer.errorMessage, systemImage: "exclamationmark.triangle")
                    .font(.footnote)
                    .foregroundStyle(.yellow)
                    .padding(.top, 4)
            }
        }
    }
    
    private func idiomDetailSection(content: IdiomContent) -> some View {
        VStack(alignment: .leading, spacing: 20) {
            HStack(alignment: .center, spacing: 14) {
                Image(systemName: "character.book.closed")
                    .font(.title3.weight(.bold))
                    .foregroundStyle(WenYanTheme.accent)
                    .padding(12)
                    .background(
                        RoundedRectangle(cornerRadius: 18, style: .continuous)
                            .fill(WenYanTheme.innerBackground)
                    )
                    .overlay(
                        RoundedRectangle(cornerRadius: 18, style: .continuous)
                            .stroke(WenYanTheme.innerStroke, lineWidth: 1)
                    )
                VStack(alignment: .leading, spacing: 4) {
                    Text("释言 · 视言 解构")
                        .font(.title3.weight(.semibold))
                        .foregroundStyle(WenYanTheme.textPrimary)
                    Text("AI 以国风笔触拆解成语含义与故事")
                        .font(.footnote)
                        .foregroundStyle(WenYanTheme.textSecondary)
                }
            }
            
            LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 18, alignment: .top), count: 3), spacing: 18) {
                idiomBlock(title: "释言（分）", text: content.shiyanFen)
                idiomBlock(title: "释言（合）", text: content.merged)
                idiomBlock(title: "视言（三脚本）") {
                    VStack(alignment: .leading, spacing: 12) {
                        idiomScriptRow(index: "一", title: "成语释义脚本", value: content.scriptMeaning)
                        idiomScriptRow(index: "二", title: "成语典故脚本", value: content.scriptStory)
                        idiomScriptRow(index: "三", title: "成语运用脚本", value: content.scriptUsage)
                    }
                }
            }
        }
    }
    
    private func idiomMediaSection(content: IdiomContent) -> some View {
        VStack(alignment: .leading, spacing: 20) {
            VStack(alignment: .leading, spacing: 6) {
                Text("多媒体创作")
                    .font(.title3.weight(.semibold))
                    .foregroundStyle(WenYanTheme.textPrimary)
                Text("一键生成国风配音与短视频，展示成语的三种面貌")
                    .font(.footnote)
                    .foregroundStyle(WenYanTheme.textSecondary)
            }
            
            HStack(spacing: 14) {
                Button(action: generateTripletVideos) {
                    actionButtonLabel(
                        icon: "video.fill",
                        title: videoComposer.isGenerating ? "生成三段视频中…" : "生成三段视频并嵌入配音",
                        gradient: WenYanTheme.secondaryGradient,
                        isDisabled: videoComposer.isGenerating
                    )
                }
                .disabled(videoComposer.isGenerating)
                
                Button(action: {
                    Task { try? await ttsClient.synthesize(text: content.shiyanFen) }
                }) {
                    actionButtonLabel(
                        icon: "speaker.wave.2.fill",
                        title: ttsClient.isLoading ? "配音生成中…" : "试听释言配音",
                        gradient: WenYanTheme.tertiaryGradient,
                        isDisabled: ttsClient.isLoading
                    )
                }
                .disabled(ttsClient.isLoading)
            }
            
            Divider()
                .background(WenYanTheme.innerStroke)
            
            TripletVideosView()
        }
    }
    
    private func idiomBlock<Content: View>(title: String, @ViewBuilder content: () -> Content) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(title)
                .font(.headline.weight(.semibold))
                .foregroundStyle(WenYanTheme.textPrimary)
            content()
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(18)
        .background(
                    RoundedRectangle(cornerRadius: 22, style: .continuous)
                        .fill(WenYanTheme.innerBackground)
                )
        .overlay(
            RoundedRectangle(cornerRadius: 22, style: .continuous)
                .stroke(WenYanTheme.innerStroke, lineWidth: 1)
        )
        .frame(maxWidth: .infinity, minHeight: 0, alignment: .topLeading)
    }
    
    private func idiomBlock(title: String, text: String) -> some View {
        idiomBlock(title: title) {
            Text(text)
                .font(.body)
                .foregroundStyle(WenYanTheme.textSecondary)
                .lineSpacing(6)
        }
    }
    
    private func idiomScriptRow(index: String, title: String, value: String) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack(spacing: 6) {
                Text(index)
                    .font(.subheadline.weight(.bold))
                    .padding(6)
                    .background(
                        Circle()
                            .fill(WenYanTheme.secondaryGradient)
                    )
                Text(title)
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(WenYanTheme.textPrimary)
            }
            Text(value)
                .font(.footnote)
                .foregroundStyle(WenYanTheme.textSecondary)
                .lineSpacing(4)
        }
    }
    
    private func actionButtonLabel(icon: String, title: String, gradient: LinearGradient, isDisabled: Bool) -> some View {
        Label {
            Text(title)
                .font(.subheadline.weight(.semibold))
        } icon: {
            Image(systemName: icon)
        }
        .labelStyle(.titleAndIcon)
        .frame(maxWidth: .infinity)
        .padding(.vertical, 14)
        .padding(.horizontal, 16)
        .background(
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .fill(isDisabled ? WenYanTheme.disabledGradient : gradient)
        )
        .overlay(
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .stroke(WenYanTheme.innerStroke, lineWidth: 1)
        )
        .foregroundStyle(WenYanTheme.textPrimary)
        .opacity(isDisabled ? 0.7 : 1)
        .animation(.easeInOut(duration: 0.2), value: isDisabled)
    }
    
    private func generateContent() {
        guard !inputText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }
        
        selectedIdiom = inputText.trimmingCharacters(in: .whitespacesAndNewlines)
        Task {
            do {
                _ = try await idiomExplainer.fetchContentAndScripts(for: selectedIdiom)
            } catch {
                // 错误处理在 IdiomExplainer 内部完成
            }
        }
    }
}

struct VideoPlayerView: View {
    let videoURL: URL
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        ZStack {
            WenYanTheme.background
                .ignoresSafeArea()
            
            VStack(spacing: 0) {
                HStack {
                    Spacer()
                    Button {
                        dismiss()
                    } label: {
                        Image(systemName: "xmark.circle.fill")
                            .font(.title2)
                            .foregroundStyle(WenYanTheme.textPrimary)
                    }
                    .buttonStyle(.plain)
                }
                .padding(.top, 16)
                .padding(.horizontal, 20)
                
                VideoPlayer(player: AVPlayer(url: videoURL))
                    .aspectRatio(16.0 / 9.0, contentMode: .fit)
                    .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
                    .padding(.all, 20)
            }
        }
    }
}

#Preview {
    ContentView()
}

class TripletVideoState: ObservableObject {
    struct Job: Identifiable, Codable {
        enum Status: String, Codable {
            case pending, tts, submitting, polling, succeeded, failed
        }

        let id: UUID
        let title: String
        let script: String
        let shortText: String
        var audioPath: String?
        var videoURL: URL?
        var taskId: String?
        var progress: Double
        var eta: Double?
        var status: Status
        var message: String?
    }

    private static let storageURL: URL = {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        return docs.appendingPathComponent("video_jobs.json")
    }()

    @Published var jobs: [Job] = [] {
        didSet { save() }
    }

    init() {
        load()
    }

    func update(jobId: UUID, mutate: (inout Job) -> Void) {
        if let idx = jobs.firstIndex(where: { $0.id == jobId }) {
            mutate(&jobs[idx])
            jobs = jobs
        }
    }

    private func save() {
        do {
            let data = try JSONEncoder().encode(jobs)
            try data.write(to: Self.storageURL, options: .atomic)
        } catch {
            print("保存视频任务失败: \(error)")
        }
    }

    private func load() {
        guard let data = try? Data(contentsOf: Self.storageURL) else { return }
        if let decoded = try? JSONDecoder().decode([Job].self, from: data) {
            jobs = decoded
        }
    }
}

private let _tripletState = TripletVideoState()

struct TripletVideosView: View {
    @ObservedObject private var s = _tripletState

    var body: some View {
        VStack(alignment: .leading, spacing: 18) {
            Text("三段视频预览")
                .font(.headline.weight(.semibold))
                .foregroundStyle(WenYanTheme.textPrimary)

            LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 16, alignment: .top), count: 3), spacing: 16) {
                ForEach(0..<3) { idx in
                    let job = s.jobs.indices.contains(idx) ? s.jobs[idx] : nil
                    VStack(alignment: .leading, spacing: 12) {
                        Text(title(for: idx))
                            .font(.subheadline.weight(.semibold))
                            .foregroundStyle(WenYanTheme.textPrimary)
                        Text(statusText(for: job))
                            .font(.caption)
                            .foregroundStyle(WenYanTheme.mutedText)
                        ProgressView(value: job?.progress ?? 0)
                            .tint(WenYanTheme.progressTint)
                        HStack {
                            Text(String(format: "进度：%.0f%%", (job?.progress ?? 0) * 100))
                            Spacer()
                            if let eta = job?.eta {
                                Text(String(format: "剩余约 %.0fs", max(0, eta)))
                            } else {
                                Text("剩余未知")
                            }
                        }
                        .font(.caption)
                        .foregroundStyle(WenYanTheme.textSecondary)

                        if let message = job?.message, !message.isEmpty {
                            Text("提示：\(message)")
                                .font(.caption)
                                .foregroundStyle(.yellow)
                        }

                        if let url = job?.videoURL {
                            VideoPlayer(player: AVPlayer(url: url))
                                .aspectRatio(16.0 / 9.0, contentMode: .fit)
                                .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                        } else {
                            ZStack {
                                RoundedRectangle(cornerRadius: 18, style: .continuous)
                                    .fill(WenYanTheme.innerBackground)
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 18, style: .continuous)
                                            .stroke(WenYanTheme.innerStroke, lineWidth: 1)
                                    )
                                VStack(spacing: 10) {
                                    Image(systemName: "film")
                                        .font(.title3)
                                        .foregroundStyle(WenYanTheme.mutedText)
                                    Text("未生成")
                                        .font(.footnote)
                                        .foregroundStyle(WenYanTheme.mutedText)
                                }
                            }
                            .aspectRatio(16.0 / 9.0, contentMode: .fit)
                        }
                    }
                    .padding(16)
                    .background(
                        RoundedRectangle(cornerRadius: 22, style: .continuous)
                            .fill(WenYanTheme.innerBackground)
                    )
                    .overlay(
                        RoundedRectangle(cornerRadius: 22, style: .continuous)
                            .stroke(WenYanTheme.innerStroke, lineWidth: 1)
                    )
                    .frame(maxWidth: .infinity, alignment: .leading)
                }
            }
        }
    }

    private func statusLabel(for status: TripletVideoState.Job.Status) -> String {
        switch status {
        case .pending: return "等待中"
        case .tts: return "配音生成中"
        case .submitting: return "提交任务"
        case .polling: return "排队轮询"
        case .succeeded: return "已完成"
        case .failed: return "需重试"
        }
    }

    private func title(for index: Int) -> String {
        switch index {
        case 0: return "成语意思"
        case 1: return "成语典故"
        default: return "成语运用"
        }
    }

    private func statusText(for job: TripletVideoState.Job?) -> String {
        guard let job else { return "等待中" }
        return statusLabel(for: job.status)
    }
}

extension ContentView {
    fileprivate func generateTripletVideos() {
        guard let c = idiomExplainer.content else { return }
        Task { await submitJobs(for: c) }
    }

    private func submitJobs(for content: IdiomContent) async {
        let shorts = content.shiyanShorts
        let titles = content.shiyanTitles
        let scripts = content.shiyanScripts

        let jobs: [TripletVideoState.Job] = zip(zip(titles, scripts), shorts).map { pair, short in
            TripletVideoState.Job(
                id: UUID(),
                title: pair.0,
                script: pair.1,
                shortText: short,
                audioPath: nil,
                videoURL: nil,
                taskId: nil,
                progress: 0,
                eta: nil,
                status: .pending,
                message: nil
            )
        }

        await MainActor.run {
            _tripletState.jobs.append(contentsOf: jobs)
            videoComposer.isGenerating = true
        }

        for job in jobs {
            await runJob(job.id)
        }

        await MainActor.run { videoComposer.isGenerating = false }
    }

    private func runJob(_ id: UUID) async {
        guard let job = await MainActor.run(body: { _tripletState.jobs.first { $0.id == id } }) else { return }

        if (job.status == .submitting || job.status == .polling), let taskId = job.taskId {
            await videoComposer.resume(taskId: taskId, onProgress: { progress, eta, status in
                Task { @MainActor in
                    _tripletState.update(jobId: job.id) { j in
                        j.progress = progress
                        j.eta = eta
                        j.status = .polling
                        j.message = status
                    }
                }
            })
            return
        }

        do {
            await MainActor.run { _tripletState.update(jobId: job.id) { j in
                j.status = .tts
                j.message = "配音生成中"
            } }

            let audioURL: URL
            if let path = job.audioPath, FileManager.default.fileExists(atPath: path) {
                audioURL = URL(fileURLWithPath: path)
            } else {
                let ttsWorker = await MainActor.run { AliTTSClient() }
                audioURL = try await ttsWorker.synthesizeToFile(text: job.shortText)
                await MainActor.run { _tripletState.update(jobId: job.id) { j in
                    j.audioPath = audioURL.path
                } }
            }

            await MainActor.run { _tripletState.update(jobId: job.id) { j in
                j.status = .submitting
                j.message = "提交视频任务"
            } }

            let videoURL = try await videoComposer.generateVideo(text: job.script, audioURL: audioURL, onProgress: { progress, eta, status in
                Task { @MainActor in
                    _tripletState.update(jobId: job.id) { j in
                        j.progress = progress
                        j.eta = eta
                        j.status = .polling
                        if j.taskId == nil {
                            j.taskId = videoComposer.lastTaskId
                        }
                        j.message = status
                    }
                }
            })

            let muxed = try await videoComposer.muxAudioAndTitle(videoURL: videoURL, audioURL: audioURL, title: job.title)
            await MainActor.run { _tripletState.update(jobId: job.id) { j in
                j.videoURL = muxed
                j.progress = 1
                j.status = .succeeded
                j.eta = 0
                j.message = nil
            } }
        } catch {
            await MainActor.run { _tripletState.update(jobId: job.id) { j in
                j.status = .failed
                j.message = error.localizedDescription
            } }

            if let taskId = await MainActor.run(body: { videoComposer.lastTaskId }) {
                await videoComposer.resume(taskId: taskId, onProgress: { progress, eta, status in
                    Task { @MainActor in
                        _tripletState.update(jobId: job.id) { j in
                            j.progress = progress
                            j.eta = eta
                            j.status = .polling
                            j.message = status
                        }
                    }
                })
                if let recovered = await MainActor.run(body: { videoComposer.videoURL }) {
                    await MainActor.run { _tripletState.update(jobId: job.id) { j in
                        j.videoURL = recovered
                        j.progress = 1
                        j.status = .succeeded
                        j.message = nil
                    } }
                }
            }
        }
    }
}
