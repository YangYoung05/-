import Foundation

/// 判断字符是否属于常见 CJK 文字或中文标点
@inline(__always)
func isCJKCharacter(_ ch: Character) -> Bool {
    guard let scalar = ch.unicodeScalars.first?.value else { return false }
    switch scalar {
    case 0x4E00...0x9FFF,   // CJK Unified Ideographs
         0x3400...0x4DBF,   // CJK Unified Ideographs Extension A
         0x20000...0x2A6DF, // Extension B
         0x2A700...0x2B73F, // Extension C
         0x2B740...0x2B81F, // Extension D
         0x2B820...0x2CEAF, // Extension E
         0x2CEB0...0x2EBEF, // Extension F
         0x3000...0x303F:   // CJK Symbols and Punctuation
        return true
    default:
        return false
    }
}
