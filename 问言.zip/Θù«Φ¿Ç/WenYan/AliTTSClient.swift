import Foundation
import Combine
import SwiftUI
import AVFoundation

#if canImport(UIKit)
import UIKit
#endif

// MARK: - 阿里云 TTS 客户端

@MainActor
class AliTTSClient: NSObject, ObservableObject {
    @Published var isLoading = false
    @Published var audioURL: URL?
    @Published var errorMessage = ""
    
    private var synthesizer: AVSpeechSynthesizer?
    private var audioPlayer: AVAudioPlayer?
    
    override init() {
        super.init()
        synthesizer = AVSpeechSynthesizer()
        configureAudioSession()
    }

    // 对外统一入口（播放+落盘）
    func synthesize(text: String) async throws {
        isLoading = true
        errorMessage = ""
        defer { isLoading = false }
        
        do {
            do {
                try await useCloudAPI(text: text)
            } catch {
                try await useSystemTTS(text: text)
            }
        } catch {
            errorMessage = "语音合成失败: \(error.localizedDescription)"
            throw error
        }
    }

    // 兼容旧命名
    func synthesizeSpeech(text: String) async { do { try await synthesize(text: text) } catch { } }

    // 云端合成（WebSocket 优先，HTTP 备用）
    private func useCloudAPI(text: String) async throws {
        print("☁️ 使用云端API合成语音")
        guard !Config.dashScopeKey.isEmpty else {
            throw NSError(domain: "TTSError", code: 0, userInfo: [NSLocalizedDescriptionKey: "API密钥未配置"])
        }

        if Config.ttsPreferWebSocket {
            do {
                try await useCloudAPIWebSocket(text: text, play: true)
                return
            } catch {
                print("WebSocket TTS失败，回退HTTP: \(error)")
            }
        }

        // 直走官方 HTTP TTS（或作为 WS 失败后的回退）
        do {
            try await useOfficialTTSHTTPEndpoint(text: text)
            return
        } catch {
            print("HTTP TTS 失败: \(error)")
            throw error
        }
    }

    // 使用 DashScope WebSocket 统一推理端点（流式）
    private func useCloudAPIWebSocket(text: String, play: Bool) async throws {
        // 长度检查（粗略：中文≈2，其他≈1），建议不超过2000
        guard billingCharCount(text) <= 2000 else {
            throw NSError(domain: "TTSError", code: 0, userInfo: [NSLocalizedDescriptionKey: "文本超出单次2000字符上限，请改用分片流式或缩短文本。"])
        }

        guard let url = URL(string: Config.ttsWebSocketURL) else {
            throw NSError(domain: "TTSError", code: 1, userInfo: [NSLocalizedDescriptionKey: "无效的WS URL"])
        }
        var request = URLRequest(url: url)
        request.setValue("Bearer \(Config.dashScopeKey)", forHTTPHeaderField: "Authorization")

        let session = makeURLSession()
        let task = session.webSocketTask(with: request)
        task.resume()

        // ---- CosyVoice v2 WebSocket 协议 ----
        // 1) 发送 START（run-task）
        let taskId = UUID().uuidString.replacingOccurrences(of: "-", with: "")
        let audioFormat = "mp3" // 可改为 "opus" 并结合 bit_rate
        let sampleRate = 22050   // cosyvoice-v2 默认 22050Hz
        let start: [String: Any] = [
            "header": [
                "action": "run-task",
                "task_id": taskId,
                "streaming": "duplex"
            ],
            "payload": [
                "model": Config.ttsModel,
                "task_group": "audio",
                "task": "tts",
                "function": "SpeechSynthesizer",
                "input": [:] as [String: Any],
                "parameters": [
                    "voice": Config.ttsVoice,
                    "volume": 50,
                    "text_type": "PlainText",
                    "sample_rate": sampleRate,
                    "rate": 1.0,
                    "format": audioFormat,
                    "pitch": 1.0,
                    "seed": 0,
                    "type": 0,
                    "enable_ssml": true,
                    "language_hints": ["zh", "en"]
                ] as [String: Any]
            ]
        ]

        // 2) 发送 CONTINUE（continue-task）携带文本
        let cont: [String: Any] = [
            "header": [
                "action": "continue-task",
                "task_id": taskId,
                "streaming": "duplex"
            ],
            "payload": [
                "model": Config.ttsModel,
                "task_group": "audio",
                "task": "tts",
                "function": "SpeechSynthesizer",
                "input": ["text": text]
            ]
        ]

        // 3) 发送 FINISH（finish-task）
        let fin: [String: Any] = [
            "header": [
                "action": "finish-task",
                "task_id": taskId,
                "streaming": "duplex"
            ],
            "payload": [
                "input": [:]
            ]
        ]

        func sendJSON(_ obj: [String: Any]) async throws {
            let data = try JSONSerialization.data(withJSONObject: obj)
            guard let text = String(data: data, encoding: .utf8) else {
                throw NSError(domain: "TTSError", code: 1, userInfo: [NSLocalizedDescriptionKey: "JSON编码失败"])
            }
            try await task.send(.string(text))
        }

        try await sendJSON(start)

        var audioBuffer = Data()
        var started = false
        var finished = false
        var failedError: NSError?

        // 并行：边收边等 started 事件，再发送 continue + finish
        let deadline = Date().addingTimeInterval(60)

        receiveLoop: while Date() < deadline {
            let message = try await task.receive()
            switch message {
            case .data(let data):
                // 二进制音频帧
                audioBuffer.append(data)
            case .string(let textMsg):
                if let obj = try? JSONSerialization.jsonObject(with: Data(textMsg.utf8)) as? [String: Any],
                   let header = obj["header"] as? [String: Any],
                   let event = header["event"] as? String {
                    if event == "task-started" {
                        if !started {
                            started = true
                            try await sendJSON(cont)
                            try await sendJSON(fin)
                        }
                    } else if event == "task-finished" {
                        finished = true
                        break receiveLoop
                    } else if event == "task-failed" {
                        let msg = (obj["message"] as? String) ?? "任务失败"
                        failedError = NSError(domain: "TTSError", code: 5, userInfo: [NSLocalizedDescriptionKey: msg])
                        break receiveLoop
                    }
                } else {
                    // 兼容输出结构：若出现 base64 音频（理论上 WS 二进制为主）
                    if let json = try? JSONSerialization.jsonObject(with: Data(textMsg.utf8)) as? [String: Any],
                       let output = json["output"] as? [String: Any],
                       let audioB64 = output["audio"] as? String,
                       let chunk = Data(base64Encoded: audioB64) {
                        audioBuffer.append(chunk)
                    }
                }
            @unknown default:
                break
            }
        }

        task.cancel(with: .normalClosure, reason: nil)
        session.invalidateAndCancel()

        if let e = failedError { throw e }
        guard finished else {
            throw NSError(domain: "TTSError", code: 6, userInfo: [NSLocalizedDescriptionKey: "语音合成未完成或超时"])
        }
        guard audioBuffer.count > 0 else {
            throw NSError(domain: "TTSError", code: 4, userInfo: [NSLocalizedDescriptionKey: "未接收到音频数据"])
        }
        try await saveAudio(audioBuffer, fileExtension: audioFormat, play: play)
    }

    // 官方 TTS HTTP 备用端点
    private func useOfficialTTSHTTPEndpoint(text: String) async throws {
        guard let url = URL(string: Config.ttsHTTPEndpoint) else {
            throw NSError(domain: "TTSError", code: 1, userInfo: [NSLocalizedDescriptionKey: "无效的TTS HTTP端点"])
        }
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("Bearer \(Config.dashScopeKey)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.timeoutInterval = 20

        // 兼容不同形态：parameters / audio / task.audio / task.parameters
        let bodies: [[String: Any]] = [
            [
                "model": Config.ttsModel,
                "input": ["text": text],
                "parameters": ["voice": Config.ttsVoice, "format": "wav", "sample_rate": 24000]
            ],
            [
                "model": Config.ttsModel,
                "input": ["text": text],
                "audio": ["voice": Config.ttsVoice, "format": "wav", "sample_rate": 24000]
            ],
            [
                "model": Config.ttsModel,
                "task": [
                    "input": ["text": text],
                    "audio": ["voice": Config.ttsVoice, "format": "wav", "sample_rate": 24000]
                ]
            ],
            [
                "model": Config.ttsModel,
                "task": [
                    "input": ["text": text],
                    "parameters": ["voice": Config.ttsVoice, "format": "wav", "sample_rate": 24000]
                ]
            ]
        ]

        let session = makeURLSession()
        var lastError: Error?
        for body in bodies {
            do {
                request.httpBody = try JSONSerialization.data(withJSONObject: body)
                let (data, response) = try await session.data(for: request)
                guard let http = response as? HTTPURLResponse else {
                    throw NSError(domain: "TTSError", code: 2, userInfo: [NSLocalizedDescriptionKey: "无效的HTTP响应"])
                }
                guard http.statusCode == 200 else {
                    let bodyStr = String(data: data, encoding: .utf8) ?? "<无法解码响应>"
                    lastError = NSError(domain: "TTSError", code: http.statusCode, userInfo: [NSLocalizedDescriptionKey: bodyStr])
                    continue
                }

                if let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any] {
                    // 常见：output.audio(base64) 或 output.audio_url
                    if let output = json["output"] as? [String: Any] {
                        if let audioB64 = output["audio"] as? String, let audioData = Data(base64Encoded: audioB64) {
                            try await saveAudio(audioData); return
                        }
                        if let audioUrlStr = output["audio_url"] as? String, let audioUrl = URL(string: audioUrlStr) {
                            let (audioData, audioResp) = try await session.data(from: audioUrl)
                            if let r = audioResp as? HTTPURLResponse, r.statusCode != 200 {
                                throw NSError(domain: "TTSError", code: r.statusCode, userInfo: [NSLocalizedDescriptionKey: "音频下载失败: status=\(r.statusCode)"])
                            }
                            try await saveAudio(audioData); return
                        }
                    }
                    // 顶层 audio
                    if let audioB64 = json["audio"] as? String, let audioData = Data(base64Encoded: audioB64) {
                        try await saveAudio(audioData); return
                    }
                }
                lastError = NSError(domain: "TTSError", code: 3, userInfo: [NSLocalizedDescriptionKey: "响应中无音频数据"])
            } catch {
                lastError = error
                continue
            }
        }
        throw lastError ?? NSError(domain: "TTSError", code: -1, userInfo: [NSLocalizedDescriptionKey: "HTTP TTS请求失败"])
    }

    // URLSession（可禁用系统代理）
    private func makeURLSession() -> URLSession {
        let config = URLSessionConfiguration.default
        if Config.disableSystemProxy { config.connectionProxyDictionary = [:] }
        config.waitsForConnectivity = true
        config.allowsExpensiveNetworkAccess = true
        config.allowsConstrainedNetworkAccess = true
        config.timeoutIntervalForRequest = 30
        config.timeoutIntervalForResource = 120
        return URLSession(configuration: config)
    }
    
    // 系统TTS（回退）
    private func useSystemTTS(text: String) async throws {
        print("🎤 使用系统TTS合成语音")
        
        await MainActor.run {
            guard let synthesizer = self.synthesizer else { return }
            if synthesizer.isSpeaking { synthesizer.stopSpeaking(at: .immediate) }
            let utterance = AVSpeechUtterance(string: text)
            utterance.voice = AVSpeechSynthesisVoice(language: "zh-CN")
            utterance.rate = AVSpeechUtteranceDefaultSpeechRate * 0.8
            utterance.volume = 1.0
            synthesizer.speak(utterance)
        }
        
        let documentsPath = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let ttsMarkerURL = documentsPath.appendingPathComponent("system_tts_\(Date().timeIntervalSince1970).txt")
        let markerContent = "✅ 系统TTS播放内容:\n\n\(text)\n\n时间: \(Date())"
        try markerContent.write(to: ttsMarkerURL, atomically: true, encoding: .utf8)
        self.audioURL = ttsMarkerURL
    }
    
    // 保存音频数据到本地文件并播放
    private func saveAudio(_ data: Data, fileExtension: String = "wav", play: Bool = true) async throws {
        guard data.count > 0 else { throw NSError(domain: "TTSError", code: 2, userInfo: [NSLocalizedDescriptionKey: "音频数据为空"]) }
        let documentsPath = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let audioURL = documentsPath.appendingPathComponent("tts_\(Date().timeIntervalSince1970).\(fileExtension)")
        try data.write(to: audioURL)
        self.audioURL = audioURL
        if play {
            do {
                self.audioPlayer = try AVAudioPlayer(data: data)
                self.audioPlayer?.prepareToPlay()
                self.audioPlayer?.play()
            } catch { /* 忽略播放错误 */ }
        }
    }
    
    // 音频会话
    private func configureAudioSession() {
        #if canImport(UIKit)
        do {
            let session = AVAudioSession.sharedInstance()
            try session.setCategory(.playback, mode: .spokenAudio, options: [.duckOthers])
            try session.setActive(true)
        } catch {
            print("Audio session failed: \(error)")
        }
        #endif
    }
    
    func quickSynthesize(text: String) async throws {
        try await useSystemTTS(text: text)
    }
}

// MARK: - 字符计费长度（粗略）
fileprivate func billingCharCount(_ text: String) -> Int {
    var count = 0
    for ch in text {
        if isCJKCharacter(ch) {
            count += 2
        } else {
            count += 1
        }
    }
    return count
}

// MARK: - 扩展：直接合成到文件并返回 URL（不播放）
extension AliTTSClient {
    func synthesizeToFile(text: String) async throws -> URL {
        isLoading = true
        errorMessage = ""
        defer { isLoading = false }
        do {
            // 走云端 WS，保存但不播放
            // 这里复用 useCloudAPIWebSocket 的保存逻辑：调用后 self.audioURL 已设置
            try await useCloudAPIWebSocket(text: text, play: false)
            guard let url = self.audioURL else {
                throw NSError(domain: "TTSError", code: -2, userInfo: [NSLocalizedDescriptionKey: "音频文件路径缺失"]) }
            return url
        } catch {
            errorMessage = error.localizedDescription
            throw error
        }
    }
}
