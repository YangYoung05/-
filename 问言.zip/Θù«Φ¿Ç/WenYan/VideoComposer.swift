import Foundation
import AVFoundation
#if canImport(AppKit)
import AppKit
#endif
import SwiftUI
import Combine
import Network

@MainActor
class VideoComposer: ObservableObject {
    private static let pendingTaskKey = "video.pending.task"
    @Published var isGenerating = false
    @Published var progress: Double = 0.0
    @Published var videoURL: URL?
    @Published var errorMessage = ""
    @Published var statusText: String = ""
    @Published var lastTaskId: String?
    @Published var etaSeconds: Double?
    @Published var estimatedFinish: Date?
    private var pathMonitor: NWPathMonitor?
    private var resumeTaskOnNetwork: String?

    func generateVideo(text: String, audioURL: URL, onProgress: ((Double, Double?, String) -> Void)? = nil) async throws -> URL {
        isGenerating = true
        progress = 0.0
        errorMessage = ""
        statusText = "提交中"
        etaSeconds = nil
        estimatedFinish = nil
        if let cb = onProgress { cb(progress, etaSeconds, statusText) }
        
        defer { 
            isGenerating = false
            progress = 0.0
        }
        
        do {
            // 下单：T2V 文生视频（异步）
            // wan 系列（含 wan2.2-t2v-plus）使用 video-synthesis 端点
            let videoSynthesisModels: Set<String> = ["wanx2.1-t2v-plus", "wan2.2-t2v-plus"]
            let useVideoSynthesisEndpoint = videoSynthesisModels.contains(Config.videoModel)
            let endpoint = useVideoSynthesisEndpoint
                ? "\(Config.baseURL)/api/v1/services/aigc/video-generation/video-synthesis"
                : "\(Config.baseURL)/api/v1/services/aigc/text-to-video/generation"
            guard let url = URL(string: endpoint) else {
                throw NSError(domain: "VideoError", code: 1, userInfo: [NSLocalizedDescriptionKey: "无效的T2V端点"])
            }
            var request = URLRequest(url: url)
            request.httpMethod = "POST"
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            request.setValue("Bearer \(Config.dashScopeKey)", forHTTPHeaderField: "Authorization")
            request.setValue("enable", forHTTPHeaderField: "X-DashScope-Async")

            // 使用可禁用代理的会话
            let cfg = URLSessionConfiguration.default
            if Config.disableSystemProxy { cfg.connectionProxyDictionary = [:] }
            let session = URLSession(configuration: cfg)

            progress = 0.2

            // 候选请求体（与 AliVideoClient 相同策略，减少端侧兼容问题）
            let promptInput: [String: Any] = ["prompt": text]
            let preferredSizeParam: [String: Any] = {
                if useVideoSynthesisEndpoint { return ["size": "832*480"] } // wan2.2 目标为 480P
                return ["size": "1280*720"]
            }()

            var candidates: [[String: Any]] = []
            if useVideoSynthesisEndpoint {
                candidates.append([
                    "model": Config.videoModel,
                    "input": promptInput,
                    "parameters": preferredSizeParam
                ])
                // 兜底：若 size 参数校验失败则回退 API 默认分辨率（通常 1080P）
                candidates.append([
                    "model": Config.videoModel,
                    "input": promptInput
                ])
            } else {
                // 兼容其他旧模型：保留原先多变体策略
                let arParam: [String: Any] = ["aspect_ratio": "16:9"]
                let durationParam: [String: Any] = ["duration": 5]
                let sizeAndDuration = preferredSizeParam.merging(durationParam) { _, new in new }
                let sizeAndAR = preferredSizeParam.merging(arParam) { _, new in new }
                let sizeArDuration = sizeAndAR.merging(durationParam) { _, new in new }
                let arAndDuration = arParam.merging(durationParam) { _, new in new }

                candidates.append(contentsOf: [
                    ["model": Config.videoModel, "input": promptInput, "parameters": preferredSizeParam],
                    ["model": Config.videoModel, "input": promptInput, "parameters": sizeAndDuration],
                    ["model": Config.videoModel, "input": promptInput, "parameters": sizeAndAR],
                    ["model": Config.videoModel, "input": promptInput, "parameters": sizeArDuration],
                    ["model": Config.videoModel, "input": promptInput, "parameters": arParam],
                    ["model": Config.videoModel, "input": promptInput, "parameters": arAndDuration],
                    ["model": Config.videoModel, "input": promptInput],
                    ["model": Config.videoModel, "input": promptInput, "parameters": durationParam]
                ])
            }

            var lastErr: NSError?
            var maybeTaskId: String?
            for (idx, body) in candidates.enumerated() {
                print("T2V(Composer) 下单尝试变体 #\(idx+1)")
                request.httpBody = try JSONSerialization.data(withJSONObject: body)
                var attempt = 0
                while attempt < 3 {
                    attempt += 1
                    let (data, response) = try await session.data(for: request)
                    guard let http = response as? HTTPURLResponse else {
                        throw NSError(domain: "VideoError", code: 2, userInfo: [NSLocalizedDescriptionKey: "无效HTTP响应"])
                    }
                    if http.statusCode == 200,
                       let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any] {
                        if let taskId = (obj["task_id"] as? String) ?? ((obj["output"] as? [String: Any])? ["task_id"] as? String) {
                            maybeTaskId = taskId
                            attempt = 999
                            break
                        }
                    }
                    let msg = String(data: data, encoding: .utf8) ?? "<无法解码响应>"
                    lastErr = NSError(domain: "VideoError", code: http.statusCode, userInfo: [NSLocalizedDescriptionKey: msg])
                    if http.statusCode == 429 {
                        let backoff = UInt64(Double(800_000_000) * pow(1.8, Double(attempt-1)))
                        try await Task.sleep(nanoseconds: backoff)
                        continue
                    }
                    if msg.contains("InvalidParameter") || msg.lowercased().contains("url error") {
                        break
                    }
                    break
                }
                if maybeTaskId != nil { break }
            }
            guard let taskId = maybeTaskId else { throw lastErr ?? NSError(domain: "VideoError", code: -1, userInfo: [NSLocalizedDescriptionKey: "T2V下单失败"]) }
            await MainActor.run { self.lastTaskId = taskId }
            persistTask(taskId)

            progress = 0.35
            statusText = "已提交，排队中"
            if let cb = onProgress { cb(progress, etaSeconds, statusText) }
            try await pollTaskAndDownload(taskId: taskId, onProgress: onProgress)
            progress = 1.0
            statusText = "SUCCEEDED"
            if let cb = onProgress { cb(progress, etaSeconds, statusText) }
            guard let url = self.videoURL else {
                throw NSError(domain: "VideoError", code: -2, userInfo: [NSLocalizedDescriptionKey: "视频保存路径丢失"]) }
            clearPersistedTask()
            return url
        } catch {
            errorMessage = "视频生成失败: \(error.localizedDescription)"
            if let urlError = error as? URLError, urlError.code == .notConnectedToInternet,
               let pending = lastTaskId {
                resumeTaskOnNetwork = pending
                startPathMonitor()
            }
            throw error
        }
    }

    /// 从已有 taskId 恢复轮询与下载
    func resume(taskId: String, onProgress: ((Double, Double?, String) -> Void)? = nil) async {
        isGenerating = true
        progress = 0.0
        errorMessage = ""
        statusText = "恢复查询中"
        etaSeconds = nil
        estimatedFinish = nil
        await MainActor.run { self.lastTaskId = taskId }
        persistTask(taskId)
        defer {
            isGenerating = false
        }
        do {
            try await pollTaskAndDownload(taskId: taskId, onProgress: onProgress)
            statusText = "SUCCEEDED"
            clearPersistedTask()
        } catch {
            errorMessage = error.localizedDescription
            resumeTaskOnNetwork = taskId
            startPathMonitor()
        }
    }

    private func pollTaskAndDownload(taskId: String, onProgress: ((Double, Double?, String) -> Void)? = nil) async throws {
        guard let url = URL(string: "\(Config.baseURL)/api/v1/tasks/\(taskId)") else {
            throw NSError(domain: "VideoError", code: 4, userInfo: [NSLocalizedDescriptionKey: "无效任务URL"])
        }
        var req = URLRequest(url: url)
        req.httpMethod = "GET"
        req.setValue("Bearer \(Config.dashScopeKey)", forHTTPHeaderField: "Authorization")
        let cfg = URLSessionConfiguration.default
        if Config.disableSystemProxy { cfg.connectionProxyDictionary = [:] }
        let session = URLSession(configuration: cfg)

        var attempt = 0
        // 用于基于斜率估算 ETA 的内部变量
        var progressStartAt: Date?
        var lastProgressAt: Date?
        var lastProgressValue: Double = 0
        var progressEMA: Double?
        var progressEMACount: Int = 0
        // 轮询上限与节奏改为可配置，以容纳更长排队时长
        let maxAttempts = Config.t2vMaxAttempts
        while attempt < maxAttempts {
            attempt += 1
            let (data, resp) = try await session.data(for: req)
            guard let http = resp as? HTTPURLResponse, http.statusCode == 200 else {
                throw NSError(domain: "VideoError", code: 5, userInfo: [NSLocalizedDescriptionKey: "查询失败"])
            }
            guard let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else {
                throw NSError(domain: "VideoError", code: 6, userInfo: [NSLocalizedDescriptionKey: "解析失败"])
            }
            let status = (obj["task_status"] as? String) ?? (obj["status"] as? String) ?? ""
            if status == "SUCCEEDED" || status == "COMPLETED" {
                if let output = obj["output"] as? [String: Any],
                   let urlStr = output["video_url"] as? String,
                   let vurl = URL(string: urlStr) {
                    let (data, _) = try await session.data(from: vurl)
                    try saveVideoData(data)
                    clearPersistedTask()
                    return
                }
                throw NSError(domain: "VideoError", code: 7, userInfo: [NSLocalizedDescriptionKey: "成功但无视频URL"])
            } else if status == "FAILED" {
                let msg = (obj["message"] as? String) ?? "任务失败"
                throw NSError(domain: "VideoError", code: 8, userInfo: [NSLocalizedDescriptionKey: msg])
            }
            // 解析精确进度：优先服务端字段，否则回退为时间代理
            if let p = Self.extractProgress(from: obj) {
                let clamped = max(0.0, min(1.0, p))
                await MainActor.run { self.progress = clamped }
                let now = Date()
                if progressStartAt == nil { progressStartAt = now }
                if let lastAt = lastProgressAt, clamped > lastProgressValue {
                    let dt = now.timeIntervalSince(lastAt)
                    if dt > 0.5 {
                        let inst = (clamped - lastProgressValue) / dt
                        let alpha = 0.3
                        if let ema = progressEMA { progressEMA = alpha * inst + (1 - alpha) * ema } else { progressEMA = inst }
                        progressEMACount += 1
                    }
                }
                lastProgressAt = now
                lastProgressValue = clamped
            } else {
                await MainActor.run { self.progress = 0.35 + 0.6 * Double(attempt) / Double(maxAttempts) }
            }
            // 解析 ETA：优先服务端字段；若无，则基于平均速率推算
            let etaParsed = Self.extractETA(from: obj)
            if let secs = etaParsed.seconds {
                await MainActor.run {
                    self.etaSeconds = max(0, secs)
                    self.estimatedFinish = etaParsed.finish ?? Date().addingTimeInterval(max(0, secs))
                }
            } else if let ema = progressEMA, progressEMACount >= 2, self.progress > 0, ema > 1e-6 {
                let remain = max(0.0, 1.0 - self.progress)
                let est = remain / ema
                await MainActor.run {
                    self.etaSeconds = est.isFinite ? max(0, est) : nil
                    self.estimatedFinish = self.etaSeconds != nil ? Date().addingTimeInterval(self.etaSeconds!) : nil
                }
            }
            await MainActor.run { self.statusText = status }
            if let cb = onProgress { cb(self.progress, self.etaSeconds, status) }
            // 根据状态选择更灵敏的轮询间隔
            let delaySec: Double
            switch status.uppercased() {
            case "PENDING": delaySec = Config.t2vDelayPending
            case "RUNNING": delaySec = Config.t2vDelayRunning
            default: delaySec = Config.t2vDelayDefault
            }
            try await Task.sleep(nanoseconds: UInt64(delaySec * 1_000_000_000))
        }
        throw NSError(domain: "VideoError", code: 9, userInfo: [NSLocalizedDescriptionKey: "超时"])
    }

    private func persistTask(_ taskId: String) {
        UserDefaults.standard.set(taskId, forKey: Self.pendingTaskKey)
    }

    private func clearPersistedTask() {
        UserDefaults.standard.removeObject(forKey: Self.pendingTaskKey)
        resumeTaskOnNetwork = nil
        stopPathMonitor()
    }

    func restorePendingTaskIfNeeded() {
        guard let taskId = UserDefaults.standard.string(forKey: Self.pendingTaskKey) else { return }
        Task { await resume(taskId: taskId) }
    }

    private func startPathMonitor() {
        guard pathMonitor == nil else { return }
        let monitor = NWPathMonitor()
        pathMonitor = monitor
        monitor.pathUpdateHandler = { [weak self] path in
            guard path.status == .satisfied else { return }
            Task { @MainActor [weak self] in
                guard let self, let pending = self.resumeTaskOnNetwork else { return }
                await self.resume(taskId: pending)
            }
        }
        monitor.start(queue: DispatchQueue(label: "video.network.monitor"))
    }

    private func stopPathMonitor() {
        pathMonitor?.cancel()
        pathMonitor = nil
    }

    /// 提取任务真实进度（0.0~1.0），字段兼容见 AliVideoClient.extractProgress
    private static func extractProgress(from obj: [String: Any]) -> Double? {
        func norm(_ v: Double) -> Double { v > 1.0 ? v/100.0 : v }
        if let output = obj["output"] as? [String: Any] {
            let keys = ["progress", "percent", "progress_percent", "video_progress", "task_progress"]
            for k in keys {
                if let v = output[k] as? Double { return norm(v) }
                if let v = output[k] as? Int { return norm(Double(v)) }
                if let vs = output[k] as? String, let v = Double(vs) { return norm(v) }
            }
            if let cur = output["current_step"] as? Int, let tot = output["total_steps"] as? Int, tot > 0 { return Double(cur)/Double(tot) }
            if let results = output["results"] as? [[String: Any]], let first = results.first {
                for k in ["progress", "percent"] {
                    if let v = first[k] as? Double { return norm(v) }
                    if let v = first[k] as? Int { return norm(Double(v)) }
                    if let vs = first[k] as? String, let v = Double(vs) { return norm(v) }
                }
            }
        }
        return nil
    }

    /// 提取 ETA（秒与预计完成时间），字段与 AliVideoClient.extractETA 对齐
    private static func extractETA(from obj: [String: Any]) -> (seconds: Double?, finish: Date?) {
        func parseSeconds(_ any: Any?) -> Double? {
            if let d = any as? Double { return d }
            if let i = any as? Int { return Double(i) }
            if let s = any as? String {
                if let v = Double(s) { return v }
                let lower = s.lowercased()
                if lower.hasSuffix("s") { return Double(lower.replacingOccurrences(of: "s", with: "")) }
                let iso = ISO8601DateFormatter()
                if let date = iso.date(from: s) { return date.timeIntervalSinceNow }
            }
            return nil
        }
        func parseDate(_ any: Any?) -> Date? {
            if let t = any as? TimeInterval { return Date(timeIntervalSince1970: t) }
            if let i = any as? Int { return Date(timeIntervalSince1970: TimeInterval(i)) }
            if let s = any as? String {
                let iso = ISO8601DateFormatter()
                if let d = iso.date(from: s) { return d }
            }
            return nil
        }
        if let output = obj["output"] as? [String: Any] {
            for k in ["eta_seconds", "remaining_seconds", "time_remaining", "remain_time", "remaining_time_sec"] {
                if let secs = parseSeconds(output[k]) { return (secs, nil) }
            }
            for k in ["expected_finish_time", "estimated_finish_time", "finish_time", "estimated_completion_time"] {
                if let d = parseDate(output[k]) { return (d.timeIntervalSinceNow, d) }
            }
            for k in ["estimated_time", "estimated_duration"] {
                if let total = parseSeconds(output[k]) {
                    if let prog = extractProgress(from: obj), prog > 0 {
                        let remain = max(0, 1 - prog) * total / max(1e-6, prog)
                        return (remain, Date().addingTimeInterval(remain))
                    }
                }
            }
        }
        return (nil, nil)
    }

    private func saveVideoData(_ data: Data) throws {
        guard data.count > 0 else { throw NSError(domain: "VideoError", code: 10, userInfo: [NSLocalizedDescriptionKey: "视频数据为空"]) }
        let documentsPath = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let localVideoURL = documentsPath.appendingPathComponent("video_\(Date().timeIntervalSince1970).mp4")
        try data.write(to: localVideoURL)
        self.videoURL = localVideoURL
    }

    // MARK: - 复合：将音频嵌入视频，并在首秒叠加标题字幕
    func muxAudioAndTitle(videoURL: URL, audioURL: URL, title: String?) async throws -> URL {
        let videoAsset = AVURLAsset(url: videoURL)
        let audioAsset = AVURLAsset(url: audioURL)

        // 新API：异步加载轨道/属性，避免 macOS 13+ 的弃用警告
        let videoTracks = try await videoAsset.loadTracks(withMediaType: .video)
        guard let videoTrack = videoTracks.first else {
            throw NSError(domain: "VideoError", code: 20, userInfo: [NSLocalizedDescriptionKey: "无视频轨道"])
        }
        let mix = AVMutableComposition()
        guard let vTrack = mix.addMutableTrack(withMediaType: .video, preferredTrackID: kCMPersistentTrackID_Invalid) else {
            throw NSError(domain: "VideoError", code: 21, userInfo: [NSLocalizedDescriptionKey: "创建视频轨失败"])
        }
        let vDuration = try await videoAsset.load(.duration)
        try vTrack.insertTimeRange(CMTimeRange(start: .zero, duration: vDuration), of: videoTrack, at: .zero)

        let audioTracks = try await audioAsset.loadTracks(withMediaType: .audio)
        if let aSrc = audioTracks.first,
           let aTrack = mix.addMutableTrack(withMediaType: .audio, preferredTrackID: kCMPersistentTrackID_Invalid) {
            let aDuration = try await audioAsset.load(.duration)
            let minDur = CMTimeMinimum(vDuration, aDuration)
            try aTrack.insertTimeRange(CMTimeRange(start: .zero, duration: minDur), of: aSrc, at: .zero)
        }

        let naturalSize = try await videoTrack.load(.naturalSize)
        let prefTransform = try await videoTrack.load(.preferredTransform)
        let size = naturalSize.applying(prefTransform)
        let videoComp = AVMutableVideoComposition()
        videoComp.renderSize = CGSize(width: abs(size.width), height: abs(size.height))
        videoComp.frameDuration = CMTime(value: 1, timescale: 30)

        let instruction = AVMutableVideoCompositionInstruction()
        instruction.timeRange = CMTimeRange(start: .zero, duration: vDuration)
        let layerInstruction = AVMutableVideoCompositionLayerInstruction(assetTrack: vTrack)
        instruction.layerInstructions = [layerInstruction]
        videoComp.instructions = [instruction]

        // 叠加标题字幕（首秒显示）
        if let title = title, !title.isEmpty {
            let parentLayer = CALayer()
            let videoLayer = CALayer()
            let overlayLayer = CATextLayer()
            parentLayer.frame = CGRect(origin: .zero, size: videoComp.renderSize)
            videoLayer.frame = parentLayer.frame
            overlayLayer.frame = CGRect(x: 40, y: videoComp.renderSize.height - 120, width: videoComp.renderSize.width - 80, height: 80)
            overlayLayer.string = NSAttributedString(string: title, attributes: [
                .font: NSFont.boldSystemFont(ofSize: 36),
                .foregroundColor: NSColor.white
            ])
            overlayLayer.alignmentMode = .left
            overlayLayer.isWrapped = true
            overlayLayer.shadowOpacity = 0.8
            overlayLayer.shadowRadius = 6
            overlayLayer.shadowOffset = CGSize(width: 2, height: -2)

            parentLayer.addSublayer(videoLayer)
            parentLayer.addSublayer(overlayLayer)

            let tool = AVVideoCompositionCoreAnimationTool(postProcessingAsVideoLayer: videoLayer, in: parentLayer)
            videoComp.animationTool = tool
        }

        let exporter = AVAssetExportSession(asset: mix, presetName: AVAssetExportPresetHighestQuality)!
        exporter.videoComposition = videoComp
        let outURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("video_vo_\(Date().timeIntervalSince1970).mp4")
        try await exporter.export(to: outURL, as: .mp4)
        return outURL
    }
}
