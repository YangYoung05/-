import Foundation
import SwiftUI
import Combine

@MainActor
class IdiomExplainer: ObservableObject {
    @Published var isLoading = false
    @Published var explanation = ""
    @Published var errorMessage = ""
    @Published var content: IdiomContent?
    
    func fetchExplanation(for idiom: String) async throws -> String {
        isLoading = true
        errorMessage = ""
        
        defer { isLoading = false }
        
        do {
            let prompt = """
            请详细解释以下成语：\(idiom)，包括：
            1. 字面意思
            2. 比喻意义  
            3. 出处典故
            4. 使用句例
            
            请用简洁明了的中文回答。
            """
            
            // 使用可禁用系统代理的会话，避免网络代理影响
            let session = Self.makeSession()
            let (data, response) = try await Self.callTextGeneration(
                session: session,
                prompt: prompt,
                preferredModel: Config.textModel,
                fallbackModel: Config.textFallbackModel,
                temperature: 0.7,
                topP: 0.8
            )
            
            guard let httpResponse = response as? HTTPURLResponse else {
                throw NSError(domain: "APIError", code: 1, userInfo: [NSLocalizedDescriptionKey: "网络请求失败"])
            }
            
            guard httpResponse.statusCode == 200 else {
                let errorMsg = "API请求失败，状态码: \(httpResponse.statusCode)"
                throw NSError(domain: "APIError", code: httpResponse.statusCode, userInfo: [NSLocalizedDescriptionKey: errorMsg])
            }
            
            guard let json = try JSONSerialization.jsonObject(with: data) as? [String: Any] else {
                throw NSError(domain: "ParseError", code: 2, userInfo: [NSLocalizedDescriptionKey: "JSON解析失败"])
            }
            
            // 检查是否有错误信息
            if let code = json["code"] as? String, code != "Success" {
                let message = json["message"] as? String ?? "未知错误"
                throw NSError(domain: "APIError", code: 3, userInfo: [NSLocalizedDescriptionKey: "API返回错误: \(message)"])
            }
            
            guard let output = json["output"] as? [String: Any],
                  let text = output["text"] as? String else {
                throw NSError(domain: "ParseError", code: 4, userInfo: [NSLocalizedDescriptionKey: "解析响应内容失败"])
            }
            
            explanation = text
            return text
        } catch {
            errorMessage = "获取解释失败: \(error.localizedDescription)"
            throw error
        }
    }

    /// 生成“释言（分/合）+ 视言”结构化内容
    func fetchContentAndScripts(for idiom: String) async throws -> IdiomContent {
        isLoading = true
        errorMessage = ""
        defer { isLoading = false }

        let prompt = """
        你是中文成语专家与短视频脚本编剧。请针对成语“\(idiom)”返回严格 JSON，键如下：
        {
          "meaning": "用简洁白话完整说明成语意思（约5秒可朗读完，信息充分、避免过度省略，建议30~60字，可 1~2 句）",
          "story": "提炼出处与典故核心（约5秒可朗读完，信息充分、避免过度省略，建议30~60字，可 1~2 句）",
          "usage": "说明常见使用语境或给出自然示例（约5秒可朗读完，信息充分、避免过度省略，建议30~60字，可 1~2 句）",
          "merged": "尽量接近200字的一段综合说明（建议180~200字），自然连贯涵盖意思、典故、运用，但不必显式列出条目",
          "script_meaning": "用于5秒短视频的画面脚本：建议写明‘镜头1/镜头2’，每个镜头包含【景别/构图/主体/动作/场景环境/光线色调/风格标签/镜头运动/时长(秒)】，语言具体、具象",
          "script_story": "同上，围绕成语典故展开的5秒画面脚本：‘镜头1/镜头2’+【景别/构图/主体/动作/场景环境/光线色调/风格标签/镜头运动/时长(秒)】",
          "script_usage": "同上，围绕成语运用展开的5秒画面脚本：‘镜头1/镜头2’+【景别/构图/主体/动作/场景环境/光线色调/风格标签/镜头运动/时长(秒)】"
        }
        要求：
        - 一定只输出 JSON，不要任何额外文字；
        - “meaning/story/usage”要信息充分、句子完整（可 1~2 句），避免过度省略导致理解困难；
        - “merged”尽量写满至200字以内（180~200字最佳），行文自然；
        - 画面脚本务必具体（如‘近景/仰拍/暖光/人物微笑/镜头推进0.5s’），且总时长约5秒；
        - 每条画面脚本都需按16:9横屏构图撰写，可在描述中标注“16:9”。
        - 使用简体中文。
        """

        let session = Self.makeSession()
        let (data, response) = try await Self.callTextGeneration(
            session: session,
            prompt: prompt,
            preferredModel: Config.textModel,
            fallbackModel: Config.textFallbackModel,
            temperature: 0.5,
            topP: 0.8
        )
        guard let http = response as? HTTPURLResponse, http.statusCode == 200 else {
            throw NSError(domain: "APIError", code: 1, userInfo: [NSLocalizedDescriptionKey: "文本生成失败"])
        }
        guard
            let json = try JSONSerialization.jsonObject(with: data) as? [String: Any],
            let output = json["output"] as? [String: Any],
            let text = output["text"] as? String
        else {
            throw NSError(domain: "ParseError", code: 2, userInfo: [NSLocalizedDescriptionKey: "响应解析失败"])
        }
        // 解析严格 JSON；若失败，尝试提取花括号段
        let parsed: [String: String]
        if let obj = try? JSONSerialization.jsonObject(with: Data(text.utf8)) as? [String: String] {
            parsed = obj
        } else if let range1 = text.range(of: "{"), let range2 = text.range(of: "}", options: .backwards) {
            let sub = String(text[range1.lowerBound...range2.upperBound])
            if let obj = try? JSONSerialization.jsonObject(with: Data(sub.utf8)) as? [String: String] {
                parsed = obj
            } else { throw NSError(domain: "ParseError", code: 3, userInfo: [NSLocalizedDescriptionKey: "JSON格式不合法"]) }
        } else {
            throw NSError(domain: "ParseError", code: 4, userInfo: [NSLocalizedDescriptionKey: "未找到JSON"]) }

        func pick(_ k: String) -> String { parsed[k]?.trimmingCharacters(in: .whitespacesAndNewlines) ?? "" }
        var item = IdiomContent(
            idiom: idiom,
            meaning: pick("meaning"),
            story: pick("story"),
            usage: pick("usage"),
            merged: pick("merged"),
            scriptMeaning: pick("script_meaning"),
            scriptStory: pick("script_story"),
            scriptUsage: pick("script_usage")
        )

        // 最终兜底：保证每段不超出 5s 估算
        item.meaning = clipToSentenceBudget(item.meaning, seconds: 5, overshootChars: 24)
        item.story   = clipToSentenceBudget(item.story, seconds: 5, overshootChars: 24)
        item.usage   = clipToSentenceBudget(item.usage, seconds: 5, overshootChars: 24)
        item.merged  = truncateChars(item.merged, limit: 200)

        self.content = item
        self.explanation = item.shiyanFen
        return item
    }
}

extension IdiomExplainer {
    private static func makeSession() -> URLSession {
        let cfg = URLSessionConfiguration.default
        if Config.disableSystemProxy { cfg.connectionProxyDictionary = [:] }
        cfg.timeoutIntervalForRequest = Config.textRequestTimeout
        cfg.timeoutIntervalForResource = Config.textRequestTimeout * Double(Config.textRequestMaxRetries)
        return URLSession(configuration: cfg)
    }

    private static func makeRequest(model: String, prompt: String, temperature: Double, topP: Double) throws -> URLRequest {
        let body: [String: Any] = [
            "model": model,
            "input": ["messages": [["role": "user", "content": prompt]]],
            "parameters": [
                "max_tokens": 500,
                "temperature": temperature,
                "top_p": topP
            ]
        ]
        var request = URLRequest(url: URL(string: "\(Config.baseURL)/api/v1/services/aigc/text-generation/generation")!)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("Bearer \(Config.dashScopeKey)", forHTTPHeaderField: "Authorization")
        request.timeoutInterval = Config.textRequestTimeout
        request.httpBody = try JSONSerialization.data(withJSONObject: body)
        return request
    }

    private static func fetchWithRetry(session: URLSession, request: URLRequest) async throws -> (Data, URLResponse) {
        var attempt = 0
        var lastError: Error?
        while attempt < Config.textRequestMaxRetries {
            do {
                return try await session.data(for: request)
            } catch {
                if let urlError = error as? URLError, urlError.code == .notConnectedToInternet {
                    throw error
                }
                lastError = error
                attempt += 1
                if attempt >= Config.textRequestMaxRetries { break }
                let backoff = Config.textRequestRetryBaseDelay * pow(2.0, Double(attempt - 1))
                try await Task.sleep(nanoseconds: UInt64(backoff * 1_000_000_000))
            }
        }
        throw lastError ?? URLError(.timedOut)
    }

    private static func callTextGeneration(
        session: URLSession,
        prompt: String,
        preferredModel: String,
        fallbackModel: String?,
        temperature: Double,
        topP: Double
    ) async throws -> (Data, URLResponse) {
        do {
            let req = try makeRequest(model: preferredModel, prompt: prompt, temperature: temperature, topP: topP)
            return try await fetchWithRetry(session: session, request: req)
        } catch {
            guard let fallback = fallbackModel, fallback != preferredModel else { throw error }
            let req = try makeRequest(model: fallback, prompt: prompt, temperature: temperature, topP: topP)
            return try await fetchWithRetry(session: session, request: req)
        }
    }
}

// MARK: - 简易时长估算与截断（中文≈0.28s/字；ASCII≈0.12s/字）
fileprivate func clipToSentenceBudget(_ text: String, seconds: Double, overshootChars: Int) -> String {
    // 预算：按中英读速估计；尽量闭合到完整句（优先向前，再容忍小幅超出向后闭句）
    let punct: Set<Character> = ["。","！","？","；","，","、",";",".","!","?"]
    var total: Double = 0
    var idx = text.startIndex
    var lastPunct: String.Index?
    while idx < text.endIndex {
        let ch = text[idx]
        let dt: Double = isCJKCharacter(ch) ? 0.28 : 0.12
        if total + dt > seconds { break }
        if punct.contains(ch) { lastPunct = idx }
        total += dt
        idx = text.index(after: idx)
    }
    if idx == text.endIndex { return text } // 未超限
    if let lp = lastPunct, text.distance(from: text.startIndex, to: lp) >= 8 {
        return String(text[...lp])
    }
    // 尝试向后找最近标点，容忍 overshootChars 个字符
    var fwd = idx
    var steps = 0
    while fwd < text.endIndex && steps < overshootChars {
        if punct.contains(text[fwd]) {
            return String(text[...fwd])
        }
        steps += 1
        fwd = text.index(after: fwd)
    }
    // 找不到标点时，返回截止到预算位置的文本
    return String(text[..<idx])
}

fileprivate func truncateChars(_ text: String, limit: Int) -> String {
    if text.count <= limit { return text }
    let idx = text.index(text.startIndex, offsetBy: limit)
    var t = String(text[..<idx])
    if !t.hasSuffix("。") && !t.hasSuffix("！") && !t.hasSuffix("？") { t += "。" }
    return t
}
