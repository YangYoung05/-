import Foundation

/// 全局配置
enum Config {
    /// ==== DashScope API配置 ====
    // API Key（与所用域名区域一致）
    // 优先从环境变量 DASHSCOPE_API_KEY 读取（macOS 调试时有用），否则回退为硬编码值。
    static let dashScopeKey: String = {
        if let key = ProcessInfo.processInfo.environment["sk-80b35017898e4fadbd31b2123ceaf26a"], !key.isEmpty {
            return key
        }
        return "sk-80b35017898e4fadbd31b2123ceaf26a"
    }()
    
    /// ==== 基础信息 ====
    static let baseURL = "https://dashscope.aliyuncs.com"
    
    /// ==== 模型名（统一） ====
    static let textModel  = "qwen-max-latest"
    static let ttsModel   = "cosyvoice-v2"
    static let ttsVoice   = "longyuan_v2"
    static let videoModel = "wan2.2-t2v-plus"

    /// ==== TTS 端点与选项 ====
    /// WebSocket（首选）
    static let ttsWebSocketURL = "wss://dashscope.aliyuncs.com/api-ws/v1/inference"
    /// HTTP 备用（只保留官方 TTS 服务这条）
    static let ttsHTTPEndpoint = "https://dashscope.aliyuncs.com/api/v1/services/tts/text-to-speech"
    /// 是否优先使用 WebSocket（若网络环境对 WS 不友好可设为 false）
    static let ttsPreferWebSocket = true

    /// ==== 网络选项 ====
    /// 建议：必要时禁用系统代理（解决 Socket is not connected/DNS 拦截等）
    static let disableSystemProxy = false

    /// ==== T2V 轮询参数（可按需调整） ====
    /// 最大轮询次数：配合下面的间隔，大约可覆盖 ~30 分钟窗口
    static let t2vMaxAttempts: Int = 360
    /// 任务处于 PENDING 排队时的轮询间隔（秒）
    static let t2vDelayPending: Double = 6
    /// 任务处于 RUNNING 执行时的轮询间隔（秒）
    static let t2vDelayRunning: Double = 4
    /// 其它状态（UNKNOWN 等）时的轮询间隔（秒）
    static let t2vDelayDefault: Double = 6

    /// ==== 文本生成请求 ====
    /// 单次请求超时时间（秒）
    static let textRequestTimeout: TimeInterval = 90
    /// 文本生成重试次数
    static let textRequestMaxRetries: Int = 4
    /// 文本生成重试基准退避（秒）
    static let textRequestRetryBaseDelay: TimeInterval = 1.8
    /// 主模型连续失败后尝试的备用模型
    static let textFallbackModel = "qwen-plus"
}
