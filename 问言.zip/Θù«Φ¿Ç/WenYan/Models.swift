import Foundation

// 仅保留应用实际使用的数据模型
// MARK: - Idiom Content Model
struct IdiomContent: Codable {
    var idiom: String
    // 释言（三段）
    var meaning: String
    var story: String
    var usage: String
    // 释言（合）200字内
    var merged: String
    // 视言（三段脚本）
    var scriptMeaning: String
    var scriptStory: String
    var scriptUsage: String

    // 释言（分）：三句合并展示（完整语句）
    var shiyanFen: String {
        "1. \(meaning)\n2. \(story)\n3. \(usage)"
    }

    var shiyanShorts: [String] { [meaning, story, usage] }
    var shiyanTitles: [String] { ["成语释义", "成语典故", "成语运用"] }
    var shiyanScripts: [String] { [scriptMeaning, scriptStory, scriptUsage] }
}
